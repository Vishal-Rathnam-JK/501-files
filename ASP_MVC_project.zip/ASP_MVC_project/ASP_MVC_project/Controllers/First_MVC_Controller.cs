﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ASP_MVC_project.Controllers
{
    public class First_MVC_Controller : Controller
    {
        //
        // GET: /First_MVC_/

        public ActionResult Show_Info()
        {
            
            return View();
        }
        public ActionResult Show_Html_Data()
        {
            return View();
        }

        public ActionResult Show_Aspx_Data()
        {
            return View();
        }
        public ActionResult manipulate_html_array()
        {
            return View();
        }
        public ActionResult collection_manipulation()
        {
            return View();
        }
        public ActionResult function_call_html()
        {
            return View();
        }
       public ActionResult function_call_aspx()
        {
            return View();
        }
       public ActionResult error_handle_html()
       {
           return View();
       }
       public ActionResult show_form_html()
       {
           return View();
       }
    }
}
