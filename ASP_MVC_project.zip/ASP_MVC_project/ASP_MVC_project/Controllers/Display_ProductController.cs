﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASP_MVC_project.Models;

namespace ASP_MVC_project.Controllers
{
    public class Display_ProductController : Controller
    {
        //
        // GET: /Display_Product/

        public ActionResult show_product()
        {
           prod_cust p = new prod_cust { prod = new product() { product_id=1,product_name="ps1" }, cust = new customer() {customer_id=1,customer_name="vishal" } };
            return View(p);
        }
        public ActionResult store_data()
        {
            
            TempData["mydata"] = 10;
            //return View("display_data");
            return RedirectToAction("display_data");
        }
        public ActionResult display_data()
        {
            return View();
        }

    }
}
