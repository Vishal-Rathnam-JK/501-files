﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASP_MVC_project.Models;

namespace ASP_MVC_project.Controllers
{
    public class html_formController : Controller
    {
        //
        // GET: /html_form/

        public ActionResult accept_emp()
        {
            return View();
        }
        public ActionResult display_emp()
        {
            employee emp = new employee(){emp_id=int.Parse( Request.Form["txt_empid"]),emp_name=Request.Form["txt_empname"],emp_sal=double.Parse(Request.Form["txt_empsal"])};
            return View(emp);
        }

    }
}
