﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASP_MVC_project.Models;

namespace ASP_MVC_project.Controllers
{
    public class html_helper_empController : Controller
    {
        //
        // GET: /html_helper_emp/

        public ActionResult read_emp()
        {
            return View();
        }
        public ActionResult write_emp(FormCollection fc)
        {
            employee emp = new employee();
            //emp.emp_id = int.Parse(Request.Form["txt_empid"]);
            //emp.emp_name = Request.Form["txt_empname"];
            //emp.emp_sal = double.Parse(Request.Form["txt_empsal"]);
            emp.emp_id = int.Parse(fc["txt_empid"]);
            emp.emp_name = fc["txt_empname"];
            emp.emp_sal = double.Parse(fc["txt_empsal"]);
            return View(emp);
        }
        public ActionResult store_model_emp()
        {
            return View();
        }
        public ActionResult display_model_emp(employee emp)
        {
            return View();
        }
    }
}
