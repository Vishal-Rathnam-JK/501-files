﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ASP_MVC_project.Controllers
{
    public class ResultController : Controller
    {
        //
        // GET: /Result/

        public ActionResult Index()
        {            
            return View();
        }
        public string show_string()
        {
            return ("Hi");
        }
        public int show_int()
        {
            return (123);
        }
        public ContentResult show_content()
        {
            return Content("hi", "text/plain", Encoding.UTF8);
        }
        public class user
        {
            public int userid { get; set; }
           
        }
        public JsonResult show_json()
        { 
            user u = new user(){userid=1};
           return Json(u,JsonRequestBehavior.AllowGet);
        }
        public ActionResult show_viewdata()
        {
           // ViewData["myinfo"] = "Rangaaaaa";
            var std = new List<string>() { "hey", "hit", "ranga" };
           // ViewData["mydata"] = std;
            ViewBag.myinfo = std;
            return View();
        }
       
    }
}
