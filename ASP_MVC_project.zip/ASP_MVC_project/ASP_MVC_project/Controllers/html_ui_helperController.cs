﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ASP_MVC_project.Controllers
{
    public class html_ui_helperController : Controller
    {
        //
        // GET: /html_ui_helper/

        public ActionResult accept_info()
        {
            return View();
        }

    }
}
