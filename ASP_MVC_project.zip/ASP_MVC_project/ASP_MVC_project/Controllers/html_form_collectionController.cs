﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASP_MVC_project.Models;

namespace ASP_MVC_project.Controllers
{
    public class html_form_collectionController : Controller
    {
        //
        // GET: /html_form_collection/

        public ActionResult add_emp()
        {
            return View();
        }
        public ActionResult print_emp(FormCollection formcollect)
        {
            employee emp = new employee();
            emp.emp_id = int.Parse(formcollect["txt_empid"]);
            emp.emp_name = formcollect["txt_empname"];
            emp.emp_sal = double.Parse(formcollect["txt_empsal"]);
            return View(emp);
        }


        [HttpPost]
        public ActionResult add_emp(FormCollection formcollect)
        {
            employee emp = new employee();
            emp.emp_id = int.Parse(formcollect["txt_empid"]);
            emp.emp_name = formcollect["txt_empname"];
            emp.emp_sal = double.Parse(formcollect["txt_empsal"]);
            return View(emp);
        }
    }
}
