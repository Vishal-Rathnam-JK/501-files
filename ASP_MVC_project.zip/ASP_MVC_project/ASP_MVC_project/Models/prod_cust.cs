﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASP_MVC_project.Models
{
    public class prod_cust
    {
        public product prod { get; set; }
        public customer cust { get; set; }
    }
}