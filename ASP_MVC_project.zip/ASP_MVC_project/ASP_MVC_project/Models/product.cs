﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASP_MVC_project.Models
{
    public class product
    {
        public int product_id { get; set; }
        public string product_name { get; set; }
    }
}