﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;

namespace BusinessAccessLayer
{
    /// <summary>
    /// Class which contains the business rules .It is accessed by the UI . This Accesses the Data Access Class.
    /// </summary>
    public class BusinessLogicClass
    {
        // object for data access layer - connectivity with database
       
        DataAccessClass dataAccess = new DataAccessClass();
      
        /// <summary>
        /// function used to get all the distinct countries to be populated in the from and to dropdown lists
        /// </summary>
        /// <returns> list of distinct countries to the webapi GetAllCountries</returns>
        
        public List<string> GetAllCountries()
        {
            try
            {          
            List<string> countryList = new List<string>();
            
                foreach (DataRow country in dataAccess.FetchFromDataBase("USP_GetCountry", null).Tables[0].Rows)
                {
                    countryList.Add(country.ItemArray[0].ToString());
                }
                return countryList;
            }
            catch (SqlException)
            {
                throw new Exception("Error");
            }
            catch (NoNullAllowedException)
            {
                throw new Exception("Error");
            }
            catch (NullReferenceException)
            {
                throw new Exception("Error");
            }
                catch(IndexOutOfRangeException)
            {
                throw new Exception("Error");
            }
            catch (Exception)
            {
                throw new Exception("Error");
            }
            
        }

        /// <summary>
        /// function used to get all the travel classes to be populated in the travel class dropdown list
        /// </summary>
        /// <returns> list of distinct countries to the webapi GetAllTravelClasses</returns>
        public List<string> GetAllTravelClasses()
        {
            try
            {          
            List<string> travelClassList = new List<string>();
           
                foreach (DataRow country in dataAccess.FetchFromDataBase("USP_GetTravelClasses", null).Tables[0].Rows)
                {
                    travelClassList.Add(country.ItemArray[0].ToString());
                }
                return travelClassList;
            }
            catch (SqlException)
            {
                throw new Exception("Error");
            }
            catch (NoNullAllowedException)
            {
                throw new Exception("Error");
            }
            catch (NullReferenceException)
            {
                throw new Exception("Error");
            }
            catch (IndexOutOfRangeException)
            {
                throw new Exception("Error");
            }
            catch (Exception)
            {
                throw new Exception("Error");
            }
        }

        

        /// <summary>
        /// function used to get all the eligible routes based on the input that the user has provided .
        /// All the values are converted as sqlparameters here
        /// </summary>
        /// <param name="departureDate">date of departure is passed as datetime </param>
        /// <param name="departurePlace">place of departure is passed as string</param>
        /// <param name="arrivalPlace">place of arrival is passed as string </param>
        /// <param name="preferredClass">preferred class is passed as string </param>
        /// <returns>a dataset which has the eligible routes to the home controller's index actionresult post type</returns>

        public DataSet GetEligibleRoutes(DateTime departureDate,string departurePlace,string arrivalPlace,string preferredClass)
        {
            try
            {

            
            //parameter for departure date 
            SqlParameter deptDate = new SqlParameter("@DepartureDate",SqlDbType.DateTime,100);
            deptDate.Value = departureDate;

            //parameter for departure place
            SqlParameter deptPlace = new SqlParameter("@DeparturePlace", SqlDbType.VarChar, 100);
            deptPlace.Value = departurePlace;

            //parameter for arrival place
            SqlParameter arrivePlace = new SqlParameter("@ArrivalPlace", SqlDbType.VarChar, 100);
            arrivePlace.Value = arrivalPlace;

            //parameter for preferred class 
            SqlParameter classPreference = new SqlParameter("@ClassType", SqlDbType.VarChar, 100);
            classPreference.Value = preferredClass;
            
            //List of all the parameters
            List<SqlParameter> parmList = new List<SqlParameter>() {deptDate,deptPlace,arrivePlace,classPreference };
           
                return dataAccess.FetchFromDataBase("USP_GetEligibleRoutes", parmList);
            }
            catch (SqlException)
            {
                throw new Exception("Error");
            }
            catch (NoNullAllowedException)
            {
                throw new Exception("Error");
            }
            catch (NullReferenceException)
            {
                throw new Exception("Error");
            }
            catch (IndexOutOfRangeException)
            {
                throw new Exception("Error");
            }
            catch (Exception)
            {
                throw new Exception("Error");
            }
        }
        
    }

}
