﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Flight_Search_UI.Models
{
    /// <summary>
    /// model which is used to store the data to be populated in the eligible routes modal
    /// </summary>
    public class EligibleRoutesClass
    {
        public string FlightName { get; set; }
        public string Airways { get; set; }
        public int AdultCapacity { get; set; }
        public int ChildrenCapacity { get; set; }
        public DateTime DepartureDate { get; set; }
        public string DeparturePlace { get; set; }
        public string DepartureCity { get; set; }
        public string ArrivalPlace { get; set; }
        public DateTime ArrivalTime { get; set; }
    }
}