﻿//global variable for checking if the returned routes are empty or no route is returned . 

var check = "none";


// function to display modal
function showModal() {
    $('#resultModal').modal('show');
}
