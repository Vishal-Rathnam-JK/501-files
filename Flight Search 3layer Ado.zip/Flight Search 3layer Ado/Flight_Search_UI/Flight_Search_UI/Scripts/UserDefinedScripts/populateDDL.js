﻿


    $(window).on("load", function (){

        //Populating the dropdown lists for the from and to places
        $.ajax({
            url: '/api/Data/GetAllCountries',
            type: "GET",
            dataType: "JSON",
            contentType: "application/JSON;charset=UTF-8",
            success: function (data) {               
                if (data[0] == "Error") {
                    alert("There are some connectivity issues . Please reload the page after sometime");
                    $("#search").css({ "display": "none" });
                }
                else {                    
                    $("#fromDDL").append(new Option("--Select--"));
                    for (var i = 0; i < data.length; i++) {
                        var info = new Option(data[i]);
                        $("#fromDDL").append(info);
                    }
                    $("#toDDL").append(new Option("--Select--"));
                    for (var i = 0; i < data.length; i++) {
                        var info = new Option(data[i]);

                        $("#toDDL").append(info);
                    }
                }
            },
            error: function (response) {
                alert(response.responseText);
            },
            failure: function (response) {
                alert(response.responseText);
            }
        });


        //Populating the travel classes dropdown list 
        $.ajax({
            url: '/api/Data/GetAllTravelClasses',
            type: "GET",
            dataType: "JSON",
            contentType: "application/JSON;charset=UTF-8",
            success: function (data) {
                if (data[0] == "Error") {
                    alert("There are some connectivity issues . Please reload the page after sometime");
                    $("#search").css({ "display": "none" });
                }
                else {


                    $("#travelClass").append(new Option("--Select--"));
                    for (var i = 0; i < data.length; i++) {
                        var info = new Option(data[i]);
                        $("#travelClass").append(info);
                    }
                }
            },
            error: function (response) {
                alert(response.responseText);
            },
            failure: function (response) {
                alert(response.responseText);
            }
        });
    });
