﻿





$(document).ready(function () {

    // validation for name input      
    $("#name").focusout(function () {
        // validation for empty name input
        if ($("#name").val().length == 0) {
            $.toaster({ priority: 'danger', title: 'Alert', message: 'Please enter your name ' });            
        }
           
    });

    $("#name").keyup(function () {
        // validation for  wrong name input


    if ($("#name").val() != $("#name").val().match(/^[a-zA-Z\s]+$/)) {
        $.toaster({ priority: 'danger', title: 'Alert', message: 'Please enter a valid name ' });
        
    }
    });

    //   validation for valid email address
    $("#email").focusout(function () {
        
        if ($("#email").val() != $("#email").val().match(/^[a-zA-Z]+[a-zA-Z0-9]+@[a-zA-Z.-]+\.[A-Za-z]{2,6}$/)) {
            $.toaster({ priority: 'info', title: 'Warning', message: 'Please enter a valid email address ' });
            
        }
    });

    // validation for departure  ddl    
    $("#fromDDL").change(function () {
    if ($("#fromDDL").val() == "--Select--" ) {
        $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select a proper departure point' });
        
    }
    });

    // validation for arrival ddl    
    $("#toDDL").change(function () {
        if ($("#toDDL").val() == "--Select--") {
            $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select a proper destination' });
            
        }
    });

    // validation for adults and children selected . validation fails if both are zero.
    $("#travelClass").focusin(function(){
        if ($("#adultsDDL").val() == 0 && $("#childrenDDL").val() == 0) {
            $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select the number of passengers properly' });
        }
            // validation for departure  ddl 
        else if ($("#fromDDL").val() == "--Select--") {
            $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select a proper departure point' });

        }
            // validation for arrival ddl
        else if ($("#toDDL").val() == "--Select--") {
            $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select a proper destination' });

        }
    });

    // validation for travel class ddl
    $("#travelClass").focusout(function () {
        if ($("#travelClass").val() == "--Select--") {
            $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select the travel class properly' });
        }
    });
    $("#travelClass").change(function () {
        if ($("#travelClass").val() == "--Select--") {
            $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select the travel class properly' });
        }
    });

    
    //Validating the inputs on search button click

    $("#search").click(function (e) {

    // validation for empty name input
    if ($("#name").val().length == 0) {
        $.toaster({ priority: 'danger', title: 'Alert', message: 'Please enter your name ' });
        e.preventDefault();
    }
        // validation for  wrong name input


    else if ($("#name").val() != $("#name").val().match(/^[a-zA-Z\s]+$/)) {
        $.toaster({ priority: 'danger', title: 'Alert', message: 'Please enter a valid name ' });
        e.preventDefault();
    }


        //   validation for valid email address
    else if ($("#email").val() != $("#email").val().match(/^[a-zA-Z]+[a-zA-Z0-9]+@[a-zA-Z.-]+\.[A-Za-z]{2,6}$/)) {
        $.toaster({ priority: 'info', title: 'Warning', message: 'Please enter a valid email address ' });
        e.preventDefault();
    }

        // validation for departure and arrival ddl    
    else if ($("#fromDDL").val() == "--Select--" || $("#toDDL").val() == "--Select--") {
        $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select the places' });
        e.preventDefault();
    }

        // validation for adults and children selected . validation fails if both are zero.
    else if ($("#adultsDDL").val() == 0 && $("#childrenDDL").val() == 0) {
        $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select the number of passengers properly' });
        e.preventDefault();
    }

        // validation for departure date selector
    else if ($("#departure").val() == "") {
        $.toaster({ priority: 'danger', title: 'Alert', message: 'Please select the date of departure' });
        e.preventDefault();
    }

        // notification of all inputs valid and data is submitted 
    else {
        $.toaster({ priority: 'success', title: 'Alert', message: 'Submitted ' });
        

    }
});
});