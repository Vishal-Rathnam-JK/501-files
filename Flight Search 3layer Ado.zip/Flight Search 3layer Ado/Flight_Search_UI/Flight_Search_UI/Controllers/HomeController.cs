﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using Flight_Search_UI.Models;
using BusinessAccessLayer;

namespace Flight_Search_UI.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            try
            {
                return View();
            }
            catch (SqlException)
            {
                return View("Error");
            }
            catch (NoNullAllowedException)
            {
                return View("Error");
            }
            catch (NullReferenceException)
            {
                return View("Error");
            }
            catch (IndexOutOfRangeException)
            {
                return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }                          
            
        }

        /// <summary>
        /// post action for index which accepts form data as form collection and returns the eligible routes to be populated in the routes modal
        /// </summary>
        /// <param name="data">formcollection </param>
        /// <returns>eligible routes bound to the eligible routes model which is used to populate the eligible routes modal  </returns>

        [HttpPost]
        public ActionResult Index(FormCollection data)
        {
            try
            {
            BusinessLogicClass businessLogic = new BusinessLogicClass();
            // variable declaration for storing form collection data        
            string RequestedDate = data["departure"];
            string RequestedFromPlace = data["fromDDL"];
            string RequestedToPlace = data["toDDL"];
            string PreferredClass = data["travelClass"];
            
            // parsing of user inputted date into valid date for sql  query
            DateTime DepartureDate = new DateTime(int.Parse(RequestedDate.Substring(0, 4)), int.Parse(RequestedDate.Substring(5, 2)), int.Parse(RequestedDate.Substring(8, 2)));
          
            //populating the eligible routes into a dataset by calling a business logic layer function using variables from ui
            DataSet eligibleRoutesDS =  businessLogic.GetEligibleRoutes(DepartureDate, RequestedFromPlace, RequestedToPlace, PreferredClass);
            
            //list containing the eligible routes
            List<EligibleRoutesClass> eligibleRoutesList = new List<EligibleRoutesClass>();
         
            //populating the list by iterating through the dataset
            foreach (DataRow row in eligibleRoutesDS.Tables[0].Rows)
          {
              // eligible route object to be stored in the eligible route list
                  EligibleRoutesClass route = new EligibleRoutesClass();
                  route.FlightName = row.ItemArray[0].ToString();
                  route.Airways = row.ItemArray[1].ToString();
                  route.AdultCapacity = (int)row.ItemArray[2];
                  route.ChildrenCapacity = (int) row.ItemArray[3];
                  route.DepartureDate = (DateTime)row.ItemArray[4];
                  route.DeparturePlace = row.ItemArray[5].ToString();
                  route.DepartureCity = row.ItemArray[6].ToString();
                  route.ArrivalPlace = row.ItemArray[7].ToString();
                  route.ArrivalTime = (DateTime) row.ItemArray[8];
                  eligibleRoutesList.Add(route);                           
          }
          return View(eligibleRoutesList);
            }
            catch (SqlException)
            {
                return View("Error");
            }
            catch (NoNullAllowedException)
            {
                return View("Error");
            }
            catch (NullReferenceException)
            {
                return View("Error");
            }
            catch (IndexOutOfRangeException)
            {
                return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }                         
        }
         }
}
