﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using BusinessAccessLayer;

namespace Flight_Search_UI.Controllers
{
    public class DataController : ApiController
    {
        // creating an object for business logic layer
        BusinessLogicClass businessLogic = new BusinessLogicClass();
       
        /// <summary>
        /// Function to get all the distinct countries to populate the from and to drop down lists
        /// </summary>
        /// <returns> list of all the distinct countries</returns>
        [HttpGet]
        public List<string> GetAllCountries()
        {
            try
            {
                return businessLogic.GetAllCountries();
            }
            catch (SqlException)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }
            catch (NoNullAllowedException)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }
            catch (NullReferenceException)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }
            catch (IndexOutOfRangeException)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }          
            catch (Exception)
            {
                List<string> errorList = new List<string>() {"Error"};
                return errorList;
            }                                   
        }

        /// <summary>
        /// Function to get all the travel classes to populate the travel class dropdownlist
        /// </summary>
        /// <returns> list of all the travel classes</returns>

        [HttpGet]
        public List<string> GetAllTravelClasses()
        {
            try
            {
                return businessLogic.GetAllTravelClasses();  
            }
            catch (SqlException)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }
            catch (NoNullAllowedException)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }
            catch (NullReferenceException)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }
            catch (IndexOutOfRangeException)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }
            catch (Exception)
            {
                List<string> errorList = new List<string>() { "Error" };
                return errorList;
            }                          
             
        }
    }
}
