﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataAccessLayer
{
    /// <summary>
    /// Class which contains the database connectivity logic. It is accessed by the Business logic class . This Accesses the Database through ado.net.
    /// </summary>
        public class DataAccessClass
        {
           /// <summary>
            /// Function which accepts the stored procedure name and parameter list and returns the resultant output as a dataset
           /// </summary>
           /// <param name="query"> sql query is passed as string</param>
           /// <param name="parameterList"> the sql parameters for the query are passed as list of sql parameters</param>
           /// <returns></returns>
            public DataSet FetchFromDataBase(string query, List<SqlParameter> parameterList)
            {
                try
                {
                    SqlConnection connectionObject = new SqlConnection(ConfigurationManager.ConnectionStrings["FlightSearchConnection"].ConnectionString);
                    connectionObject.Open();
                    SqlCommand commandObject = connectionObject.CreateCommand();
                    commandObject.CommandType = CommandType.StoredProcedure;
                    commandObject.CommandText = query;
                    if (parameterList != null)
                    {
                        foreach (SqlParameter parameter in parameterList)
                        {
                            commandObject.Parameters.Add(parameter);
                        }
                    }
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(commandObject);
                    DataSet resultDataset = new DataSet();
                    dataAdapter.Fill(resultDataset);
                    connectionObject.Close();
                    return resultDataset;
                }
                catch (SqlException)
                {
                    throw new Exception("Error");
                }
                catch (NoNullAllowedException)
                {
                    throw new Exception("Error");
                }
                catch (NullReferenceException)
                {
                    throw new Exception("Error"); 
                }
                catch (Exception)
                {
                    throw new Exception("Error");
                }
            }
        }



    }

