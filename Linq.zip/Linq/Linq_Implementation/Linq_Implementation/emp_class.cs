﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq_Implementation
{
    class emp_class
    {
        public static void Main()
        {
            List<employee> emp = new List<employee>()
                             {
                                 new employee{emp_id=1,emp_name="aaa",emp_city="austin"},
                                 new employee{emp_id=2,emp_name="bbb",emp_city="austin"},
                                 new employee{emp_id=3,emp_name="ccc",emp_city="chennai"},
                                 new employee{emp_id=4,emp_name="ddd",emp_city="austin"},
                                 new employee{emp_id=5,emp_name="eee",emp_city="austin"},
                                 new employee{emp_id=6,emp_name="fff",emp_city="chennai"},
                                 new employee{emp_id=7,emp_name="ggg",emp_city="austin"},
                                 new employee{emp_id=8,emp_name="hhh",emp_city="chennai"},
                                 new employee{emp_id=9,emp_name="iii",emp_city="chennai"},
                                 new employee{emp_id=10,emp_name="jjj",emp_city="kansas"},
                                 new employee{emp_id=11,emp_name="kkk",emp_city="kansas"},
                                 new employee{emp_id=12,emp_name="lll",emp_city="kansas"}
                             };
//                       // display all employees who's id is lesser than 4
            //var output = from a in emp where a.emp_id < 4 select a;
            //foreach (employee item in output)
            //{
            //    Console.WriteLine(item.emp_name);
            //}

//                      //  using lambda
            //var output = emp.Where(c => c.emp_id < 4);
            //foreach (employee item in output)
            //{
            //    Console.WriteLine(item.emp_name);
            //}



//          // display city name and number of employees working in that city
            //var output = from a in emp group a by a.emp_city into res select new { city = res.key, total = res.count() };
            //foreach (var item in output)
            //{
            //    console.writeline(item.city + "    " + item.total);
            //}
//            //         using lambda
            //var output = emp.GroupBy(c => c.emp_city).Select(res => new { city = res.Key, total = res.Count() });
            //foreach (var item in output)
            //{
            //    Console.WriteLine(item.city + "    " + item.total);
            //}



//                 // display the cities and employees working in the city            
            var city = from a in emp group a by a.emp_city into res select new { data = res.Key };            
            foreach (var item in city)
            {
                Console.WriteLine(item.data);
                var names = from a in emp where a.emp_city == item.data select a;
                foreach (var name in names)
                {
                    Console.WriteLine(name.emp_name); 
                }
            }
            Console.ReadLine();
        }
    }
    public class employee
    {
       public int emp_id{get;set;}
       public string emp_name{get;set;}
       public string emp_city{get;set;}
    }
}
