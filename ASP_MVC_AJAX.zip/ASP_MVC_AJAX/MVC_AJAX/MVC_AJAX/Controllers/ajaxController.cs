﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_AJAX.Models;
using System.Threading;

namespace MVC_AJAX.Controllers
{
    public class ajaxController : Controller
    {
        dream_homeEntities dhe = new dream_homeEntities();
        //
        // GET: /ajax/

        public ActionResult Index()
        {
            
            return View();
        }

        public ActionResult All()
        {
            Thread.Sleep(4000);
            List<tblStudent> li = dhe.tblStudents.ToList();
            return PartialView("_student", li);
        }

        public ActionResult Top_3()
        {
            Thread.Sleep(4000);
            List<tblStudent> li = dhe.tblStudents.OrderByDescending(m => m.TotalMarks).Take(3).ToList();
            return PartialView("_student", li);
        }

        public ActionResult Bottom_3()
        {
            Thread.Sleep(4000);
            List<tblStudent> li = dhe.tblStudents.OrderBy(m => m.TotalMarks).Take(3).ToList();
            return PartialView("_student", li);
        }

    }
}
