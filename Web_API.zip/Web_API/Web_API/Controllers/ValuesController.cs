﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ClassLibrary1;

namespace Web_API.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<branch> Get()
        {
            dream_homeEntities1 de = new dream_homeEntities1();
            return de.branches.ToList();
            //return new string[] { "value1", "value2" };
        }

        //[HttpPost]
        //public IEnumerable<branch> Get(string branch)
        //{
        //    dream_homeEntities1 de = new dream_homeEntities1();
        //    return de.branches.Where(i=> i.branchno==branch).ToList();
        //    //return new string[] { "value1", "value2" };
        //}

        // GET api/values/5
        public IEnumerable<branch> Get(string branch)
        {
            dream_homeEntities1 de = new dream_homeEntities1();
            return de.branches.Where(i => i.branchno == branch).ToList();
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}