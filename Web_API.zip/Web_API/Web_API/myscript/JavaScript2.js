﻿
$(document).ready(function () {
    
    $("#btn_submit").click(function () {
        var id = $("#branch").val();
        $.ajax({
            url: 'api/values?branch='+id,
            async: false,
            contentType: "application/json;char-set=utf-8",
            dataType: "json",
            data: { branchno: id },
            success: function (data) {
                var t = $('#data').dataTable().api();
                t.clear().draw();
                $.each(data, function (i, val) {
                    
                    t.row.add([
                        val.branchno,
                        val.street,
                        val.city,
                        val.postcode

                    ]).draw();
                });

            },
            error: function (xhr, ajaxOption, thrownError) {
                console.error(xhr.responseText);
                console.error(thrownError);
            },
            statusCode:
                {
                    404: function () {
                        alert("No records found to display");
                    }
                }
        });
    });
   
    });
