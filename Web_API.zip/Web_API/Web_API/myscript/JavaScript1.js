﻿$(document).ready(function () {
    GetData();
    function GetData() {
        $.ajax({
            url: "api/values",
            async: false,
            contentType: "application/json;char-set=utf-8",
            dataType: "json",
            success: function (data) {
                
                var t = $('#data').dataTable().api();

                $.each(data, function (i, val) {
                    
                    t.row.add([
                        val.branchno,
                        val.street,
                        val.city,
                        val.postcode
                        
                        ]).draw();
                });

            },
            error: function (xhr, ajaxOption, thrownError) {
                console.error(xhr.responseText);
                console.error(thrownError);
            },
            statusCode:
                {
                    404: function () {
                        alert("No records found to display");
                    }
                }
        });
    }
   
});