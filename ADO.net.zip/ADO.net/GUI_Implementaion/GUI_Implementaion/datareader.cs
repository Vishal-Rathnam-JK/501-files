﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GUI_Implementaion
{
    public partial class datareader : Form
    {
        SqlConnection con; 
        SqlCommand cmd;
        SqlDataReader dr;
        public datareader()
        {
            InitializeComponent();
        }
        private void btn_next_Click(object sender, EventArgs e)
        {
            if (dr.Read())
            {
             txt_branchno.Text = dr[0].ToString();
             txt_street.Text = dr[1].ToString();
             txt_city.Text = dr[2].ToString();
             txt_postcode.Text = dr[3].ToString();
            }
            else
            {
                MessageBox.Show("Last record reached");
            }
        }
        private void datareader_Load(object sender, EventArgs e)
        {
         string constring = "server=pc251462;database=dream_home;integrated security=false;user id=sa;password=password-1";
         string query = "select * from branch";
         con = new SqlConnection(constring);
         con.Open();
         cmd = new SqlCommand(query, con);
         dr = cmd.ExecuteReader();
         if (dr.Read())
         {
             txt_branchno.Text = dr[0].ToString();
             txt_street.Text = dr[1].ToString();
             txt_city.Text = dr[2].ToString();
             txt_postcode.Text = dr[3].ToString();
         }
         else
         {
             MessageBox.Show("NO records in table");
         }
        }
    }
}
