﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GUI_Implementaion
{
    public partial class combo_box : Form
    {
        public combo_box()
        {
            InitializeComponent();
        }

        private void combo_box_Load(object sender, EventArgs e)
        {
            string constring = "server=pc251462;database=CHN17ID001;integrated security=false;user id=sa;password=password-1";
            string query = "select distinct addres from customer where addres is not null";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cb_city.Items.Add(dr[0].ToString());
                //cb_city.Items.Add(dr["addres"].ToString());
                 //cb_city.Items.Add(dr.GetSqlValue(0));
            }
        }

        private void cb_city_SelectedIndexChanged(object sender, EventArgs e)
        {
            string constring = "server=pc251462;database=CHN17ID001;integrated security=false;user id=sa;password=password-1";
            string query = "select * from customer where addres=@adr";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            //SqlCommand cmd = con.CreateCommand();
            //cmd.CommandType = CommandType.Text;
            //cmd.CommandText = query;

               //            OR   


            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter adapt = new SqlDataAdapter();
            SqlParameter sp = cmd.Parameters.Add("@adr", SqlDbType.VarChar, 200);
            sp.Value = cb_city.Text;
            adapt = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            adapt.Fill(ds1, "cust");
            dataGrid1.DataSource = ds1.Tables["cust"];
        }
    }
}
