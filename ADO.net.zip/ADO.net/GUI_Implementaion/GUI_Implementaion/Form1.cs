﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Implementaion
{
    public partial class form_validate : Form
    {
        public form_validate()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_validate_Click(object sender, EventArgs e)
        {
            string uname = txt_user_name.Text;
            string pwd = txt_password.Text;
            if (uname=="sa" && pwd=="password-1")
            {
                MessageBox.Show("Welcome User");
            }
            else
            {
                MessageBox.Show("Invalid Credentials");
            }
        }

        private void form_validate_Load(object sender, EventArgs e)
        {

        }
    }
}
