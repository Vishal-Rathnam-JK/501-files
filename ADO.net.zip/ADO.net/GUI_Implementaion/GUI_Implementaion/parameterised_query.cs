﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GUI_Implementaion
{
    public partial class parameterised_query : Form
    {
        SqlConnection con;
        SqlCommand com;
        //SqlDataReader read;
        SqlDataAdapter adapt;
        DataSet ds1;
        public parameterised_query()
        {
            InitializeComponent();
        }

        
        private void parameterised_query_Load(object sender, EventArgs e)
        {

        }

        private void btn_client_accept_Click(object sender, EventArgs e)
        {
            txt_branchno.DataBindings.Clear();
            txt_staffno.DataBindings.Clear();
            txt_doj.DataBindings.Clear();
            //txt_branchno.DataBindings.Clear("Text", ds1, "reg.branchno");
            //txt_staffno.DataBindings.Clear("Text", ds1, "reg.staffno");
            //txt_doj.DataBindings.Clear("Text", ds1, "reg.datejoined");
            string constring = "server=pc251462;database=dream_home;integrated security=false;user id=sa;password=password-1";
            string query = "select * from registration where clientno=@cno";
            this.con = new SqlConnection(constring);
            this.con.Open();
            this.com = con.CreateCommand();
            com.CommandType = CommandType.Text;
            com.CommandText = query;

                 //            OR
           
            
            // SqlCommand com = new SqlCommand(query, con);
            SqlParameter sp = com.Parameters.Add("@cno",SqlDbType.VarChar,7);
            sp.Value = txt_clientno.Text;
            adapt = new SqlDataAdapter(com);
            this.ds1 = new DataSet();
            adapt.Fill(ds1,"reg");
            if (ds1.Tables["reg"].Rows.Count==1)
            {
                txt_branchno.DataBindings.Add("Text", ds1, "reg.branchno");
                txt_staffno.DataBindings.Add("Text", ds1, "reg.staffno");
                txt_doj.DataBindings.Add("Text", ds1, "reg.datejoined");
            }
            else
            {
                MessageBox.Show("NO clients present");
            }
        }
    }
}
