﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GUI_Implementaion
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            string constring = "server=pc251462;database=dream_home;integrated security=false;user id=sa;password=password-1";
            string query = "select * from client";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand(query, con);
            SqlDataAdapter dadapt = new SqlDataAdapter(com);
            SqlCommand com1 = new SqlCommand("select * from staff", con);
            SqlDataAdapter dadapt1 = new SqlDataAdapter(com1);
            DataSet ds1 = new DataSet();
            dadapt.Fill(ds1,"Client");
            dadapt1.Fill(ds1, "Staff");
            dataGrid1.DataSource = ds1;
        }
    }
}
