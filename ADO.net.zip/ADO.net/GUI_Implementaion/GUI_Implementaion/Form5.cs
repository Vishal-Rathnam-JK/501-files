﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GUI_Implementaion
{
    public partial class Form5 : Form
    {
        SqlConnection con;
        SqlCommand com;
        SqlDataAdapter dadapt;
        DataSet ds1;
        public Form5()
        {
            InitializeComponent();
        }

       
        private void Form5_Load(object sender, EventArgs e)
        {
            string constring = "server=pc251462;database=dream_home;integrated security=false;user id=sa;password=password-1";
            string query = "select * from branch";
             this.con = new SqlConnection(constring);
            this.con.Open();
            this.com = new SqlCommand(query, con);
             this.dadapt = new SqlDataAdapter(com);                       
            this.ds1 = new DataSet();
            dadapt.Fill(ds1, "Branch");
            txt_branch.DataBindings.Add("Text", ds1, "branch.branchno");
            txt_street.DataBindings.Add("Text", ds1, "branch.street");
            txt_city.DataBindings.Add("Text", ds1, "Branch.city");
            txt_postcode.DataBindings.Add("Text", ds1, "Branch.postcode");
            
            
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds1, "branch"].Position++;
        }

        private void btn_previous_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds1, "branch"].Position--;
        }

        private void btn_first_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds1, "branch"].Position=0;
        }

        private void btn_last_Click(object sender, EventArgs e)
        {
           this.BindingContext[ds1, "branch"].Position = this.BindingContext[ds1,"branch"].Count-1;
        }

       

       

        
    }
}
