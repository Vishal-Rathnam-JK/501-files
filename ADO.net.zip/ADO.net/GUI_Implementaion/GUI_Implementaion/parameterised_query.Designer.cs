﻿namespace GUI_Implementaion
{
    partial class parameterised_query
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_clientno = new System.Windows.Forms.Label();
            this.lbl_branchno = new System.Windows.Forms.Label();
            this.lbl_staffno = new System.Windows.Forms.Label();
            this.lbl_datejonied = new System.Windows.Forms.Label();
            this.txt_clientno = new System.Windows.Forms.TextBox();
            this.txt_branchno = new System.Windows.Forms.TextBox();
            this.txt_staffno = new System.Windows.Forms.TextBox();
            this.txt_doj = new System.Windows.Forms.TextBox();
            this.btn_client_accept = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_clientno
            // 
            this.lbl_clientno.AutoSize = true;
            this.lbl_clientno.Location = new System.Drawing.Point(249, 114);
            this.lbl_clientno.Name = "lbl_clientno";
            this.lbl_clientno.Size = new System.Drawing.Size(96, 13);
            this.lbl_clientno.TabIndex = 0;
            this.lbl_clientno.Text = "Enter the  client no";
            // 
            // lbl_branchno
            // 
            this.lbl_branchno.AutoSize = true;
            this.lbl_branchno.Location = new System.Drawing.Point(249, 175);
            this.lbl_branchno.Name = "lbl_branchno";
            this.lbl_branchno.Size = new System.Drawing.Size(55, 13);
            this.lbl_branchno.TabIndex = 1;
            this.lbl_branchno.Text = "branch no";
            // 
            // lbl_staffno
            // 
            this.lbl_staffno.AutoSize = true;
            this.lbl_staffno.Location = new System.Drawing.Point(249, 231);
            this.lbl_staffno.Name = "lbl_staffno";
            this.lbl_staffno.Size = new System.Drawing.Size(42, 13);
            this.lbl_staffno.TabIndex = 2;
            this.lbl_staffno.Text = "staff no";
            // 
            // lbl_datejonied
            // 
            this.lbl_datejonied.AutoSize = true;
            this.lbl_datejonied.Location = new System.Drawing.Point(249, 286);
            this.lbl_datejonied.Name = "lbl_datejonied";
            this.lbl_datejonied.Size = new System.Drawing.Size(59, 13);
            this.lbl_datejonied.TabIndex = 3;
            this.lbl_datejonied.Text = "date joined";
            // 
            // txt_clientno
            // 
            this.txt_clientno.Location = new System.Drawing.Point(392, 107);
            this.txt_clientno.Name = "txt_clientno";
            this.txt_clientno.Size = new System.Drawing.Size(100, 20);
            this.txt_clientno.TabIndex = 4;
            // 
            // txt_branchno
            // 
            this.txt_branchno.Enabled = false;
            this.txt_branchno.Location = new System.Drawing.Point(392, 168);
            this.txt_branchno.Name = "txt_branchno";
            this.txt_branchno.Size = new System.Drawing.Size(100, 20);
            this.txt_branchno.TabIndex = 5;
            // 
            // txt_staffno
            // 
            this.txt_staffno.Enabled = false;
            this.txt_staffno.Location = new System.Drawing.Point(392, 224);
            this.txt_staffno.Name = "txt_staffno";
            this.txt_staffno.Size = new System.Drawing.Size(100, 20);
            this.txt_staffno.TabIndex = 6;
            // 
            // txt_doj
            // 
            this.txt_doj.Enabled = false;
            this.txt_doj.Location = new System.Drawing.Point(392, 279);
            this.txt_doj.Name = "txt_doj";
            this.txt_doj.Size = new System.Drawing.Size(100, 20);
            this.txt_doj.TabIndex = 7;
            // 
            // btn_client_accept
            // 
            this.btn_client_accept.Location = new System.Drawing.Point(534, 104);
            this.btn_client_accept.Name = "btn_client_accept";
            this.btn_client_accept.Size = new System.Drawing.Size(75, 23);
            this.btn_client_accept.TabIndex = 8;
            this.btn_client_accept.Text = "Display";
            this.btn_client_accept.UseVisualStyleBackColor = true;
            this.btn_client_accept.Click += new System.EventHandler(this.btn_client_accept_Click);
            // 
            // parameterised_query
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 499);
            this.Controls.Add(this.btn_client_accept);
            this.Controls.Add(this.txt_doj);
            this.Controls.Add(this.txt_staffno);
            this.Controls.Add(this.txt_branchno);
            this.Controls.Add(this.txt_clientno);
            this.Controls.Add(this.lbl_datejonied);
            this.Controls.Add(this.lbl_staffno);
            this.Controls.Add(this.lbl_branchno);
            this.Controls.Add(this.lbl_clientno);
            this.Name = "parameterised_query";
            this.Text = "parameterised_query";
            this.Load += new System.EventHandler(this.parameterised_query_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_clientno;
        private System.Windows.Forms.Label lbl_branchno;
        private System.Windows.Forms.Label lbl_staffno;
        private System.Windows.Forms.Label lbl_datejonied;
        private System.Windows.Forms.TextBox txt_clientno;
        private System.Windows.Forms.TextBox txt_branchno;
        private System.Windows.Forms.TextBox txt_staffno;
        private System.Windows.Forms.TextBox txt_doj;
        private System.Windows.Forms.Button btn_client_accept;
    }
}