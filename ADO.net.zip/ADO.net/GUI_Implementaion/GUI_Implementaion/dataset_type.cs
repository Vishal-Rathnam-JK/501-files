﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GUI_Implementaion
{
    public partial class dataset_type : Form
    {
        public dataset_type()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "server=pc251462;database=dream_home;integrated security=false;user id=sa;password=password-1";
            string query = "select * from staff";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter adapt = new SqlDataAdapter(cmd);
            DataSet ds1 = new DataSet();
            adapt.Fill(ds1,"staff");
            dataGrid1.DataSource = ds1.Tables["staff"];
            //richTextBox1.Text = ds1.GetXml();
            richTextBox1.Text = ds1.GetXmlSchema();
            
        }
    }
}
