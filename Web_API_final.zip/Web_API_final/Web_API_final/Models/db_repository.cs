﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;

namespace Web_API_final.Models
{
    public class db_repository
    {
        string constring = "server=PC251462;database=dream_home;integrated security=false;user id=sa;password=password-1";
        public List<string> populate_branch()
        {
            SqlConnection con = new SqlConnection(constring);
            string query = "select distinct branchno from branch";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            List<string> branch_list = new List<string>();
            while (dr.Read())
            {
                branch_list.Add(dr[0].ToString());
            }
            return branch_list;
        }

        public branch display_branch(string brno)
        {
            branch b = new branch();
            SqlConnection con = new SqlConnection(constring);
            string query = "select * from branch where branchno=" + brno;
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                b.branch_no = dr[0].ToString();
               b.street = dr[1].ToString();
               b.city = dr[2].ToString();
                b.postcode =  dr[3].ToString();

            }
            return b;
        }

        public string add_branch(branch br)
        {
            SqlConnection con = new SqlConnection(constring);
            string query = "insert into branch values(@branchno,@street,@city,@postcode)";
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            con.Open();
            cmd.Parameters.AddWithValue("@branchno", br.branch_no);
            cmd.Parameters.AddWithValue("@street", br.street);
            cmd.Parameters.AddWithValue("@city", br.city);
            cmd.Parameters.AddWithValue("@postcode", br.postcode);
            int res = cmd.ExecuteNonQuery();
            if (res==1)
            {
                return "Value inserted";
            }
            else
            {
                return "Insertion Failed";
            }
        }

        public string remove_branch(string bno)
        {
            SqlConnection con = new SqlConnection(constring);
            string query = "delete from branch where branchno="+bno;
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            con.Open();
            int res = cmd.ExecuteNonQuery();
            if (res == 1)
            {
                return bno+" deleted";
            }
            else
            {
                return  bno+" deletion Failed";
            }
        }

        public string update_branch(branch br)
        {
            SqlConnection con = new SqlConnection(constring);
            string query = " update branch set street=@street,city=@city,postcode=@postcode where branchno=@branchno";
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            con.Open();
            cmd.Parameters.AddWithValue("@branchno", br.branch_no);
            cmd.Parameters.AddWithValue("@street", br.street);
            cmd.Parameters.AddWithValue("@city", br.city);
            cmd.Parameters.AddWithValue("@postcode", br.postcode);
            int res = cmd.ExecuteNonQuery();
            if (res == 1)
            {
                return "Row updated";
            }
            else
            {
                return "Row updation Failed";
            }
        }
    }
}