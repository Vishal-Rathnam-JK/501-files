﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API_final.Models;

namespace Web_API_final.Controllers
{
    public class productController : ApiController
    {
        [HttpPost]
        public product show_prod_info(product pr)
        {
            return pr;
        }
    }
}
