﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Web_API_final.Controllers
{
    public class branch_mvcController : Controller
    {
        //
        // GET: /branch_mvc/

        public ActionResult Index()
        {
            return View();
        }


        public ActionResult insert_branch()
        {
            return View();
        }

        public ActionResult delete_branch()
        {
            return View();
        }

        public ActionResult update_branch()
        {
           return View();
        }
    }
}
