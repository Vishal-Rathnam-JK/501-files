﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API_final.Models;

namespace Web_API_final.Controllers
{
    public class branch_apiController : ApiController
    {
        db_repository dbrep = new db_repository();
        public IEnumerable<string> get_all_branch()
        {
            string[] branch_no = dbrep.populate_branch().ToArray();
            return branch_no;
        }

        public branch get_branch_details(string brno)
        {
            return dbrep.display_branch(brno);
        }

        [HttpPost]
        public string add_branch(branch br)
        {
            return dbrep.add_branch(br);
        }

        [HttpDelete]
        public string delete_branch(string bno)
        {
            return dbrep.remove_branch(bno);
        }

        [HttpPut]
        public string update_branch(branch br)
        {
            return dbrep.update_branch(br);
        }
    }
}
