﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;
namespace jquery_examples
{
    public partial class jquery_auto_complete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           

        }
        [WebMethod]
        public static string[] Getremarks(string rem)
        {
            List<string> lst = new List<string>();
            SqlConnection con = new SqlConnection("server=pc251462;database=CHN17ID001;integrated security=false;user id=sa;password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand("select remarks from info where remarks like '%" + rem + "%'", con);
            SqlDataReader read = cmd.ExecuteReader();
            while (read.Read())
            {
                lst.Add(read.GetString(0));
            }
            return lst.ToArray();
        }

    }
}