﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_Jquery.Models;
using System.Data.Entity;

namespace MVC_Jquery.Controllers
{
    public class JqueryController : Controller
    {
        //
        // GET: /Jquery/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult date_picker()
        {
            dream_homeEntities dhe = new dream_homeEntities();
            List<string> position = dhe.staffs.Select(i => i.oposition).Distinct().ToList();
            return View(position);
        }


        public ActionResult auto_complete_without_db()
        {
            return View();
        }

        public JsonResult auto_complete_with_db(string name)
        {
            
            dream_homeEntities dhe = new dream_homeEntities();
            var res = dhe.tblStudents.Where(i => i.Name.Contains(name)).Select(i=>i.Name);
            return Json(res);
        }

        public ActionResult auto_complete_with_db_ex()
        {
            return View();
        }
    }
}
