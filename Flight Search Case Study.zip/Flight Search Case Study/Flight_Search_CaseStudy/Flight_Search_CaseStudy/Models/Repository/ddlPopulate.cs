﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Flight_Search_CaseStudy.Models.Repository
{
    public class ddlPopulate
    {
    }
}