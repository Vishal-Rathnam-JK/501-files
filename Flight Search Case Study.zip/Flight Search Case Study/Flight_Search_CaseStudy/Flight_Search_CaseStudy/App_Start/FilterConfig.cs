﻿using System.Web;
using System.Web.Mvc;

namespace Flight_Search_CaseStudy
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}