﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Flight_Search_CaseStudy.Models;
namespace Flight_Search_CaseStudy.Controllers
{
    public class DataController : ApiController
    {


        /// <summary>
        /// Gets all the countries to populate the dropdown
        /// </summary>
        /// <returns> list of countries</returns>
        [HttpGet]

        public List<string> get_all_places()
        {
            flight_searchEntities1 routes = new flight_searchEntities1();
            return (routes.airportDetails.Select(i => i.country).Distinct()).ToList();
        }
    }
}
