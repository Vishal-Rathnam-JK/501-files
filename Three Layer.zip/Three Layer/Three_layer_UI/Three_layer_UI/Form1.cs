﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;
////using My_first_library;


//namespace Three_layer_UI
//{
//    public partial class Form1 : Form
//    {
//        public Form1()
//        {
//            InitializeComponent();
//        }

//        private void btn_show_Click(object sender, EventArgs e)
//        {
//            Class1 c1 = new Class1();
//           MessageBox.Show (c1.display_welcome());
//           Db_class db = new Db_class();
//           dataGrid1.DataSource=db.show_record();
//        }
//    }
//}
