﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_logic_layer;

namespace Three_layer_UI
{
    public partial class three_layer_access : Form
    {
        public three_layer_access()
        {
            InitializeComponent();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            Class1 c1 = new Class1();
           MessageBox.Show(c1.save_into_db(txt_brno.Text, textBox2.Text, textBox3.Text, textBox4.Text).ToString()+" Rows affected");
            

        }

        private void three_layer_access_Load(object sender, EventArgs e)
        {
            Class1 c1 = new Class1();
            txt_brno.Text = c1.create_new_brno();
            textBox3.Enabled = true;
            textBox2.Enabled = true;
            textBox4.Enabled = true;
        }
    }
}
