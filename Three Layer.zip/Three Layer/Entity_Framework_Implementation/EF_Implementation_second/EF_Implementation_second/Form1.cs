﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Data.Objects;
//using System.Data.Entity;


namespace EF_Implementation_second
{
    public partial class Form1 : Form
    {
        CHN17ID001Entities dbe;
        public Form1()
        {
            dbe = new CHN17ID001Entities();
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_first_Click(object sender, EventArgs e)
        {
            //dbe = new CHN17ID001Entities();
            if (dbe.products.Count()>1)
            {
               // var first = dbe.products.Select(d => new { d.prod_id, d.prod_name, d.mfg_date, d.exp_date, d.price, d.company }).FirstOrDefault();                                 
                   // new ObjectContext("Select value first from dbe.products as first");
               // string fir = dbe.Database.SqlQuery<string>("select prod_name from product").FirstOrDefault<string>();
               // MessageBox.Show(fir);
                var first = dbe.products.SqlQuery("select prod_id,prod_name,mfg_date,exp_date,price,company from product").FirstOrDefault();// using native sql
                txt_prod_id.Text = first.prod_id.ToString();
                txt_prod_name.Text = first.prod_name;
                string str = first.mfg_date.ToString();
                txt_mfg_date.Text = first.mfg_date.ToString();
                txt_expiry_date.Text = first.exp_date.ToString();
                txt_price.Text = first.price.ToString();
                txt_company.Text = first.company;
            }
           
        }

        private void btn_last_Click(object sender, EventArgs e)
        {
            //dbe = new CHN17ID001Entities();
            var first = dbe.products.OrderByDescending(d=>d.prod_id).Select(d => new { d.prod_id, d.prod_name, d.mfg_date, d.exp_date, d.price, d.company }).FirstOrDefault();
            txt_prod_id.Text = first.prod_id.ToString();
            txt_prod_name.Text = first.prod_name;
            txt_mfg_date.Text = first.mfg_date.ToString();
            txt_expiry_date.Text = first.exp_date.ToString();
            txt_price.Text = first.price.ToString();
            txt_company.Text = first.company;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           // var info = dbe.products;
           // MessageBox.Show(info.ToString());
            int total = dbe.products.Count();
            if (total > 0)
            {
                var first = (from s in dbe.products orderby s.prod_id select s).FirstOrDefault();
                txt_prod_id.Text = first.prod_id.ToString();
                txt_prod_name.Text = first.prod_name;
                txt_mfg_date.Text = first.mfg_date.ToString();
                txt_expiry_date.Text = first.exp_date.ToString();
                txt_price.Text = first.price.ToString();
                txt_company.Text = first.company;
            }
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            var value = Int32.Parse(txt_prod_id.Text);
            if (txt_prod_id.Text!=dbe.products.Max(d=>d.prod_id).ToString())
            {
                var next = dbe.products.Where(d=>d.prod_id>value).OrderBy(d=>d.prod_id).Select(d => new { d.prod_id, d.prod_name, d.mfg_date, d.exp_date, d.price, d.company }).FirstOrDefault();
                txt_prod_id.Text = next.prod_id.ToString();
                txt_prod_name.Text = next.prod_name;
                txt_mfg_date.Text = next.mfg_date.ToString();
                txt_expiry_date.Text = next.exp_date.ToString();
                txt_price.Text = next.price.ToString();
                txt_company.Text = next.company;
            }
        }

        private void btn_prev_Click(object sender, EventArgs e)
        {
            var value = Int32.Parse(txt_prod_id.Text);
            if (txt_prod_id.Text != dbe.products.Min(d => d.prod_id).ToString())
            {
                var prev = dbe.products.Where(d => d.prod_id < value).OrderByDescending(d => d.prod_id).Select(d => new { d.prod_id, d.prod_name, d.mfg_date, d.exp_date, d.price, d.company }).FirstOrDefault();
                txt_prod_id.Text = prev.prod_id.ToString();
                txt_prod_name.Text = prev.prod_name;
                txt_mfg_date.Text = prev.mfg_date.ToString();
                txt_expiry_date.Text = prev.exp_date.ToString();
                txt_price.Text = prev.price.ToString();
                txt_company.Text = prev.company;
            }
        }
    }
    public class poco : Form
    {
        public CHN17ID001Entities dbe = new CHN17ID001Entities();
        public void abc()
        {
            int total = dbe.products.Count();
            if (total > 0)
            {
                var first = (from s in dbe.products orderby s.prod_id select s).FirstOrDefault();
                //   //txt_prod_id.Text = first.prod_id.ToString();
                //   //txt_prod_name.Text = first.prod_name;
                //   //txt_mfg_date.Text = first.mfg_date.ToString();
                //   //txt_expiry_date.Text = first.exp_date.ToString();
                //   //txt_price.Text = first.price.ToString();
                //   //txt_company.Text = first.company;
            }
        }
    }
}
