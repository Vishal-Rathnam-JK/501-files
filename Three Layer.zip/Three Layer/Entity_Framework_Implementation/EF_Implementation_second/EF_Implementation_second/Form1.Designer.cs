﻿namespace EF_Implementation_second
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_product_id = new System.Windows.Forms.Label();
            this.lbl_product_name = new System.Windows.Forms.Label();
            this.lbl_mfg_date = new System.Windows.Forms.Label();
            this.lbl_expiry_date = new System.Windows.Forms.Label();
            this.lbl_price = new System.Windows.Forms.Label();
            this.lbl_company = new System.Windows.Forms.Label();
            this.txt_prod_id = new System.Windows.Forms.TextBox();
            this.txt_prod_name = new System.Windows.Forms.TextBox();
            this.txt_mfg_date = new System.Windows.Forms.TextBox();
            this.txt_expiry_date = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.txt_company = new System.Windows.Forms.TextBox();
            this.btn_first = new System.Windows.Forms.Button();
            this.btn_prev = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_last = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_product_id
            // 
            this.lbl_product_id.AutoSize = true;
            this.lbl_product_id.Location = new System.Drawing.Point(40, 101);
            this.lbl_product_id.Name = "lbl_product_id";
            this.lbl_product_id.Size = new System.Drawing.Size(54, 13);
            this.lbl_product_id.TabIndex = 0;
            this.lbl_product_id.Text = "product id";
            this.lbl_product_id.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_product_name
            // 
            this.lbl_product_name.AutoSize = true;
            this.lbl_product_name.Location = new System.Drawing.Point(161, 101);
            this.lbl_product_name.Name = "lbl_product_name";
            this.lbl_product_name.Size = new System.Drawing.Size(72, 13);
            this.lbl_product_name.TabIndex = 1;
            this.lbl_product_name.Text = "product name";
            // 
            // lbl_mfg_date
            // 
            this.lbl_mfg_date.AutoSize = true;
            this.lbl_mfg_date.Location = new System.Drawing.Point(277, 101);
            this.lbl_mfg_date.Name = "lbl_mfg_date";
            this.lbl_mfg_date.Size = new System.Drawing.Size(90, 13);
            this.lbl_mfg_date.TabIndex = 2;
            this.lbl_mfg_date.Text = "manufacture date";
            // 
            // lbl_expiry_date
            // 
            this.lbl_expiry_date.AutoSize = true;
            this.lbl_expiry_date.Location = new System.Drawing.Point(421, 101);
            this.lbl_expiry_date.Name = "lbl_expiry_date";
            this.lbl_expiry_date.Size = new System.Drawing.Size(58, 13);
            this.lbl_expiry_date.TabIndex = 3;
            this.lbl_expiry_date.Text = "expiry date";
            // 
            // lbl_price
            // 
            this.lbl_price.AutoSize = true;
            this.lbl_price.Location = new System.Drawing.Point(563, 101);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(30, 13);
            this.lbl_price.TabIndex = 4;
            this.lbl_price.Text = "price";
            // 
            // lbl_company
            // 
            this.lbl_company.AutoSize = true;
            this.lbl_company.Location = new System.Drawing.Point(686, 101);
            this.lbl_company.Name = "lbl_company";
            this.lbl_company.Size = new System.Drawing.Size(50, 13);
            this.lbl_company.TabIndex = 5;
            this.lbl_company.Text = "company";
            // 
            // txt_prod_id
            // 
            this.txt_prod_id.Location = new System.Drawing.Point(12, 150);
            this.txt_prod_id.Name = "txt_prod_id";
            this.txt_prod_id.Size = new System.Drawing.Size(100, 20);
            this.txt_prod_id.TabIndex = 6;
            // 
            // txt_prod_name
            // 
            this.txt_prod_name.Location = new System.Drawing.Point(149, 150);
            this.txt_prod_name.Name = "txt_prod_name";
            this.txt_prod_name.Size = new System.Drawing.Size(100, 20);
            this.txt_prod_name.TabIndex = 7;
            // 
            // txt_mfg_date
            // 
            this.txt_mfg_date.Location = new System.Drawing.Point(267, 150);
            this.txt_mfg_date.Name = "txt_mfg_date";
            this.txt_mfg_date.Size = new System.Drawing.Size(100, 20);
            this.txt_mfg_date.TabIndex = 8;
            // 
            // txt_expiry_date
            // 
            this.txt_expiry_date.Location = new System.Drawing.Point(401, 150);
            this.txt_expiry_date.Name = "txt_expiry_date";
            this.txt_expiry_date.Size = new System.Drawing.Size(100, 20);
            this.txt_expiry_date.TabIndex = 9;
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(532, 150);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(100, 20);
            this.txt_price.TabIndex = 10;
            // 
            // txt_company
            // 
            this.txt_company.Location = new System.Drawing.Point(656, 150);
            this.txt_company.Name = "txt_company";
            this.txt_company.Size = new System.Drawing.Size(100, 20);
            this.txt_company.TabIndex = 11;
            // 
            // btn_first
            // 
            this.btn_first.Location = new System.Drawing.Point(56, 270);
            this.btn_first.Name = "btn_first";
            this.btn_first.Size = new System.Drawing.Size(75, 23);
            this.btn_first.TabIndex = 12;
            this.btn_first.Text = "First";
            this.btn_first.UseVisualStyleBackColor = true;
            this.btn_first.Click += new System.EventHandler(this.btn_first_Click);
            // 
            // btn_prev
            // 
            this.btn_prev.Location = new System.Drawing.Point(191, 270);
            this.btn_prev.Name = "btn_prev";
            this.btn_prev.Size = new System.Drawing.Size(75, 23);
            this.btn_prev.TabIndex = 13;
            this.btn_prev.Text = "Previous";
            this.btn_prev.UseVisualStyleBackColor = true;
            this.btn_prev.Click += new System.EventHandler(this.btn_prev_Click);
            // 
            // btn_next
            // 
            this.btn_next.Location = new System.Drawing.Point(349, 270);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(75, 23);
            this.btn_next.TabIndex = 14;
            this.btn_next.Text = "Next";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_last
            // 
            this.btn_last.Location = new System.Drawing.Point(532, 270);
            this.btn_last.Name = "btn_last";
            this.btn_last.Size = new System.Drawing.Size(75, 23);
            this.btn_last.TabIndex = 15;
            this.btn_last.Text = "Last";
            this.btn_last.UseVisualStyleBackColor = true;
            this.btn_last.Click += new System.EventHandler(this.btn_last_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 555);
            this.Controls.Add(this.btn_last);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.btn_prev);
            this.Controls.Add(this.btn_first);
            this.Controls.Add(this.txt_company);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.txt_expiry_date);
            this.Controls.Add(this.txt_mfg_date);
            this.Controls.Add(this.txt_prod_name);
            this.Controls.Add(this.txt_prod_id);
            this.Controls.Add(this.lbl_company);
            this.Controls.Add(this.lbl_price);
            this.Controls.Add(this.lbl_expiry_date);
            this.Controls.Add(this.lbl_mfg_date);
            this.Controls.Add(this.lbl_product_name);
            this.Controls.Add(this.lbl_product_id);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_product_id;
        private System.Windows.Forms.Label lbl_product_name;
        private System.Windows.Forms.Label lbl_mfg_date;
        private System.Windows.Forms.Label lbl_expiry_date;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Label lbl_company;
        private System.Windows.Forms.TextBox txt_prod_id;
        private System.Windows.Forms.TextBox txt_prod_name;
        private System.Windows.Forms.TextBox txt_mfg_date;
        private System.Windows.Forms.TextBox txt_expiry_date;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.TextBox txt_company;
        private System.Windows.Forms.Button btn_first;
        private System.Windows.Forms.Button btn_prev;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_last;
    }
}

