﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Entity_Framework_Implementation
{
    public partial class join_using_equals : Form
    {
        public join_using_equals()
        {
            InitializeComponent();
        }

        private void join_using_equals_Load(object sender, EventArgs e)
        {
            dream_homeEntities2 dbe = new dream_homeEntities2();
           // dataGrid1.DataSource=(from s in dbe.staffs join d in dbe.registrations on s.staffno equals d.staffno select new { s.fname,s.oposition,d.datejoined}).ToList();
            dataGrid1.DataSource = dbe.staffs.Join(dbe.registrations, first => first.staffno, second => second.staffno, (staf, reg) => new { s = staf, r = reg }).Select(c => new { c.s.fname, c.s.oposition, c.r.datejoined }).ToList();

        }
    }
}
