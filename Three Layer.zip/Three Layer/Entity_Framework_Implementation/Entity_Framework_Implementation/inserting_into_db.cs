﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace Entity_Framework_Implementation
{    
    public partial class inserting_into_db : Form
    {
        dream_homeEntities2 dbe;
        public inserting_into_db()
        {
            dbe = new dream_homeEntities2();
            InitializeComponent();
        }

        private void inserting_into_db_Load(object sender, EventArgs e)
        {
            int new_num;
            string new_branch;
            var branch = (from s in dbe.branches orderby s.branchno descending select s).FirstOrDefault(); 
            //var branch = dbe.branches.Max();
            int oldno = Int32.Parse(branch.branchno.Substring(1, 3));
            if (oldno<9)
            {
                new_num = oldno + 1;
                new_branch = branch.branchno.Substring(0, 3) + new_num;
            }
            else if (oldno>8 && oldno < 99)
            {
                new_num = oldno + 1;
                new_branch = branch.branchno.Substring(0, 2) + new_num; 
            }
            else
            {
                new_num = oldno + 1;
                new_branch = branch.branchno.Substring(0, 1) + new_num; 
            }
            txt_branchno.Text = new_branch;

        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            if (txt_city.Text!=""||txt_postcode.Text!=""||txt_street.Text!="")
            {
                branch b = new branch { branchno = txt_branchno.Text, street = txt_street.Text, city = txt_city.Text, postcode = txt_postcode.Text };
                //branch b = new branch()
                //b.branchno = txt_branchno.Text;
                //b.street = txt_street.Text;
                //b.city = txt_city.Text;
                //b.postcode = txt_postcode.Text;
                dbe.branches.Attach(b);
                dbe.branches.Add(b);
             int rec =   dbe.SaveChanges();
             MessageBox.Show(rec + " rows affected");
             if (rec>0)
             {
                int new_num;
            string new_branch;
            var branch = (from s in dbe.branches orderby s.branchno descending select s).FirstOrDefault(); 
            //var branch = dbe.branches.Max();
            int oldno = Int32.Parse(branch.branchno.Substring(1, 3));
            if (oldno<9)
            {
                new_num = oldno + 1;
                new_branch = branch.branchno.Substring(0, 3) + new_num;
            }
            else if (oldno>8 && oldno < 99)
            {
                new_num = oldno + 1;
                new_branch = branch.branchno.Substring(0, 2) + new_num; 
            }
            else
            {
                new_num = oldno + 1;
                new_branch = branch.branchno.Substring(0, 1) + new_num; 
            }
            txt_branchno.Text = new_branch; 
             }
            }
        }
    }
}
