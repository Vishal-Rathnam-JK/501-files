﻿namespace Entity_Framework_Implementation
{
    partial class stored_procedure_with_out
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_submit = new System.Windows.Forms.Button();
            this.lbl_branchno = new System.Windows.Forms.Label();
            this.txt_branchno = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(222, 122);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(75, 23);
            this.btn_submit.TabIndex = 0;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // lbl_branchno
            // 
            this.lbl_branchno.AutoSize = true;
            this.lbl_branchno.Location = new System.Drawing.Point(228, 19);
            this.lbl_branchno.Name = "lbl_branchno";
            this.lbl_branchno.Size = new System.Drawing.Size(58, 13);
            this.lbl_branchno.TabIndex = 1;
            this.lbl_branchno.Text = "Branch No";
            // 
            // txt_branchno
            // 
            this.txt_branchno.Location = new System.Drawing.Point(211, 61);
            this.txt_branchno.Name = "txt_branchno";
            this.txt_branchno.Size = new System.Drawing.Size(100, 20);
            this.txt_branchno.TabIndex = 2;
            // 
            // stored_procedure_with_out
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 505);
            this.Controls.Add(this.txt_branchno);
            this.Controls.Add(this.lbl_branchno);
            this.Controls.Add(this.btn_submit);
            this.Name = "stored_procedure_with_out";
            this.Text = "stored_procedure_with_out";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.Label lbl_branchno;
        private System.Windows.Forms.TextBox txt_branchno;
    }
}