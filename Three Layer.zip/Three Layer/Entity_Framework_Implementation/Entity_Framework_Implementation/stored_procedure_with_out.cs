﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Objects; // for object parameter

namespace Entity_Framework_Implementation
{
    public partial class stored_procedure_with_out : Form
    {
        public stored_procedure_with_out()
        {
            InitializeComponent();
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            dream_homeEntities2 dbe = new dream_homeEntities2();
           ObjectParameter count = new ObjectParameter("scount",typeof(int));// using system.data.objects
            dbe.disp_staff_branch(txt_branchno.Text,count);
            MessageBox.Show("The number of staffs are " + (int)count.Value);
        }
    }
}
