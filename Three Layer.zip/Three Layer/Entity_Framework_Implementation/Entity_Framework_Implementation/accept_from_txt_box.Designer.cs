﻿namespace Entity_Framework_Implementation
{
    partial class accept_from_txt_box
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_branchno = new System.Windows.Forms.TextBox();
            this.txt_street = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.txt_postcode = new System.Windows.Forms.TextBox();
            this.lbl_branch_no = new System.Windows.Forms.Label();
            this.lbl_street = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_postcode = new System.Windows.Forms.Label();
            this.btn_submit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_branchno
            // 
            this.txt_branchno.Location = new System.Drawing.Point(75, 88);
            this.txt_branchno.Name = "txt_branchno";
            this.txt_branchno.Size = new System.Drawing.Size(100, 20);
            this.txt_branchno.TabIndex = 0;
            this.txt_branchno.TextChanged += new System.EventHandler(this.txt_branchno_TextChanged);
            // 
            // txt_street
            // 
            this.txt_street.Enabled = false;
            this.txt_street.Location = new System.Drawing.Point(263, 88);
            this.txt_street.Name = "txt_street";
            this.txt_street.Size = new System.Drawing.Size(100, 20);
            this.txt_street.TabIndex = 1;
            // 
            // txt_city
            // 
            this.txt_city.Enabled = false;
            this.txt_city.Location = new System.Drawing.Point(452, 88);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(100, 20);
            this.txt_city.TabIndex = 2;
            // 
            // txt_postcode
            // 
            this.txt_postcode.Enabled = false;
            this.txt_postcode.Location = new System.Drawing.Point(621, 88);
            this.txt_postcode.Name = "txt_postcode";
            this.txt_postcode.Size = new System.Drawing.Size(100, 20);
            this.txt_postcode.TabIndex = 3;
            // 
            // lbl_branch_no
            // 
            this.lbl_branch_no.AutoSize = true;
            this.lbl_branch_no.Location = new System.Drawing.Point(94, 50);
            this.lbl_branch_no.Name = "lbl_branch_no";
            this.lbl_branch_no.Size = new System.Drawing.Size(58, 13);
            this.lbl_branch_no.TabIndex = 4;
            this.lbl_branch_no.Text = "Branch No";
            // 
            // lbl_street
            // 
            this.lbl_street.AutoSize = true;
            this.lbl_street.Location = new System.Drawing.Point(291, 50);
            this.lbl_street.Name = "lbl_street";
            this.lbl_street.Size = new System.Drawing.Size(35, 13);
            this.lbl_street.TabIndex = 5;
            this.lbl_street.Text = "Street";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(481, 50);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(24, 13);
            this.lbl_city.TabIndex = 6;
            this.lbl_city.Text = "City";
            // 
            // lbl_postcode
            // 
            this.lbl_postcode.AutoSize = true;
            this.lbl_postcode.Location = new System.Drawing.Point(647, 50);
            this.lbl_postcode.Name = "lbl_postcode";
            this.lbl_postcode.Size = new System.Drawing.Size(56, 13);
            this.lbl_postcode.TabIndex = 7;
            this.lbl_postcode.Text = "Post Code";
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(327, 197);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(75, 23);
            this.btn_submit.TabIndex = 8;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // accept_from_txt_box
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 562);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.lbl_postcode);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_street);
            this.Controls.Add(this.lbl_branch_no);
            this.Controls.Add(this.txt_postcode);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.txt_street);
            this.Controls.Add(this.txt_branchno);
            this.Name = "accept_from_txt_box";
            this.Text = "accept_from_txt_box";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_branchno;
        private System.Windows.Forms.TextBox txt_street;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.TextBox txt_postcode;
        private System.Windows.Forms.Label lbl_branch_no;
        private System.Windows.Forms.Label lbl_street;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_postcode;
        private System.Windows.Forms.Button btn_submit;
    }
}