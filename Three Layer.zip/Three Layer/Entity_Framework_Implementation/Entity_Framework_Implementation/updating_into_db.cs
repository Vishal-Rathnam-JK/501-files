﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Entity_Framework_Implementation
{
    public partial class updating_into_db : Form
    {
        dream_homeEntities2 dbe;
        public updating_into_db()
        {
            dbe = new dream_homeEntities2();
            InitializeComponent();
        }

        private void btn_retrieve_Click(object sender, EventArgs e)
        {
            var res = dbe.branches.Where(s => s.branchno == txt_branchno.Text).FirstOrDefault();
            if (res == null)
            {
                MessageBox.Show("no such records found");
            }
            else
            {
                txt_branchno.Text = res.branchno;
                txt_branchno.Enabled = false;
                txt_street.Text = res.street;
                txt_street.Enabled = true;
                txt_city.Text = res.city;
                txt_city.Enabled = true;
                txt_postcode.Text = res.postcode;
                txt_postcode.Enabled = true;              
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            branch b = dbe.branches.Where(s => s.branchno == txt_branchno.Text).FirstOrDefault() ;
            b.street = txt_street.Text;
            b.city = txt_city.Text;
            b.postcode = txt_postcode.Text;
            MessageBox.Show( dbe.SaveChanges().ToString()+" rows updated");
        }
    }
}
