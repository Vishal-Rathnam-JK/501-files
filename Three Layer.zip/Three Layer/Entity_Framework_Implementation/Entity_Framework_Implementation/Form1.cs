﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace Entity_Framework_Implementation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           // dream_homeEntities2 dbe = new dream_homeEntities2();
           // dataGrid1.DataSource = (from s in dbe.staffs select s).ToList();
           // dataGrid1.DataSource = dbe.staffs.Select(d => new { d.staffno, d.fname, d.lname, d.salary }).ToList();

            
//               // displaying staffno,sname,salary and number of registrations done by staff
            //dataGrid1.DataSource = dbe.staffs.Select(d => new { staffnumber = d.staffno, name = d.fname, amount = d.salary, registrationcount = d.registrations.Count }).ToList();


//               // displaying propertynumber,city,fname of staff from propertyforrent
          //  dataGrid1.DataSource = dbe.propertyforrents.Select(d => new { d.propertyno, d.city }).ToList();

        }
    }
}
