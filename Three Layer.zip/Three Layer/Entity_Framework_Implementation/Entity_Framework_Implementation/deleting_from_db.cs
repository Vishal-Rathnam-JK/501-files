﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Entity_Framework_Implementation
{
    public partial class deleting_from_db : Form
    {
        dream_homeEntities2 dbe;
        public deleting_from_db()
        {
            dbe = new dream_homeEntities2();
            InitializeComponent();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            var res = dbe.branches.Where(s => s.branchno == txt_branchno.Text).FirstOrDefault();
            if (res==null)
            {
                MessageBox.Show("no such records found");
            }
            else
            {
                
                dbe.branches.Remove(dbe.branches.Where(d=> d.branchno==res.branchno).First());
                
                MessageBox.Show(dbe.SaveChanges().ToString()+" rows deleted");
            }
        }
    }
}
