﻿namespace Entity_Framework_Implementation
{
    partial class dropdown_display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.combo_branch = new System.Windows.Forms.ComboBox();
            this.lbl_branchno = new System.Windows.Forms.Label();
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // combo_branch
            // 
            this.combo_branch.FormattingEnabled = true;
            this.combo_branch.Location = new System.Drawing.Point(292, 12);
            this.combo_branch.Name = "combo_branch";
            this.combo_branch.Size = new System.Drawing.Size(121, 21);
            this.combo_branch.TabIndex = 0;
            this.combo_branch.SelectedIndexChanged += new System.EventHandler(this.combo_branch_SelectedIndexChanged);
            // 
            // lbl_branchno
            // 
            this.lbl_branchno.AutoSize = true;
            this.lbl_branchno.Location = new System.Drawing.Point(150, 20);
            this.lbl_branchno.Name = "lbl_branchno";
            this.lbl_branchno.Size = new System.Drawing.Size(58, 13);
            this.lbl_branchno.TabIndex = 1;
            this.lbl_branchno.Text = "Branch No";
            // 
            // dataGrid1
            // 
            this.dataGrid1.DataMember = "";
            this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid1.Location = new System.Drawing.Point(12, 159);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.Size = new System.Drawing.Size(736, 305);
            this.dataGrid1.TabIndex = 2;
            // 
            // dropdown_display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 476);
            this.Controls.Add(this.dataGrid1);
            this.Controls.Add(this.lbl_branchno);
            this.Controls.Add(this.combo_branch);
            this.Name = "dropdown_display";
            this.Text = "dropdown_display";
            this.Load += new System.EventHandler(this.dropdown_display_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combo_branch;
        private System.Windows.Forms.Label lbl_branchno;
        private System.Windows.Forms.DataGrid dataGrid1;
    }
}