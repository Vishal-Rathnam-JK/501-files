﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Entity_Framework_Implementation
{
    public partial class accept_from_txt_box : Form
    {
        public accept_from_txt_box()
        {
            InitializeComponent();
        }

        private void txt_branchno_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            dream_homeEntities2 dbe = new dream_homeEntities2();

           // int count = dbe.branches.Where(b => b.branchno == txt_branchno.Text).Count();
           // if (count>0)
            //{
            //    var result = dbe.branches.Where(d => d.branchno == txt_branchno.Text).Select(d => new { d.branchno, d.street, d.city, d.postcode }).First();
            //     txt_street.Text = result.street;
            //    txt_city.Text = result.city;
            //    txt_postcode.Text = result.postcode;          
            //}
                 var result = dbe.branches.Where(d => d.branchno == txt_branchno.Text).Select(d => new {d.street, d.city, d.postcode }).FirstOrDefault();
                if (result!=null)
                {
                    txt_street.Text = result.street;
                    txt_city.Text = result.city;
                    txt_postcode.Text = result.postcode;                    
                }
            else
            {
                MessageBox.Show("No Such Branch Number");
                txt_street.Text = "";
                txt_city.Text = "";
                txt_postcode.Text = "";
            }
        }
    }
}
