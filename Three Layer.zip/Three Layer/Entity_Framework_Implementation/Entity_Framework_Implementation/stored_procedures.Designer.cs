﻿namespace Entity_Framework_Implementation
{
    partial class stored_procedures
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_branch_no = new System.Windows.Forms.Label();
            this.txt_branchno = new System.Windows.Forms.TextBox();
            this.lbl_street = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_street = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.txt_postcode = new System.Windows.Forms.TextBox();
            this.btn_submit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_branch_no
            // 
            this.lbl_branch_no.AutoSize = true;
            this.lbl_branch_no.Location = new System.Drawing.Point(64, 63);
            this.lbl_branch_no.Name = "lbl_branch_no";
            this.lbl_branch_no.Size = new System.Drawing.Size(55, 13);
            this.lbl_branch_no.TabIndex = 0;
            this.lbl_branch_no.Text = "branch no";
            // 
            // txt_branchno
            // 
            this.txt_branchno.Location = new System.Drawing.Point(48, 111);
            this.txt_branchno.Name = "txt_branchno";
            this.txt_branchno.Size = new System.Drawing.Size(100, 20);
            this.txt_branchno.TabIndex = 1;
            // 
            // lbl_street
            // 
            this.lbl_street.AutoSize = true;
            this.lbl_street.Location = new System.Drawing.Point(259, 63);
            this.lbl_street.Name = "lbl_street";
            this.lbl_street.Size = new System.Drawing.Size(33, 13);
            this.lbl_street.TabIndex = 2;
            this.lbl_street.Text = "street";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(519, 63);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(23, 13);
            this.lbl_city.TabIndex = 3;
            this.lbl_city.Text = "city";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(692, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "post code";
            // 
            // txt_street
            // 
            this.txt_street.Location = new System.Drawing.Point(237, 111);
            this.txt_street.Name = "txt_street";
            this.txt_street.Size = new System.Drawing.Size(100, 20);
            this.txt_street.TabIndex = 5;
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(475, 111);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(100, 20);
            this.txt_city.TabIndex = 6;
            // 
            // txt_postcode
            // 
            this.txt_postcode.Location = new System.Drawing.Point(660, 111);
            this.txt_postcode.Name = "txt_postcode";
            this.txt_postcode.Size = new System.Drawing.Size(100, 20);
            this.txt_postcode.TabIndex = 7;
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(351, 199);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(75, 23);
            this.btn_submit.TabIndex = 8;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // stored_procedures
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 529);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.txt_postcode);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.txt_street);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_street);
            this.Controls.Add(this.txt_branchno);
            this.Controls.Add(this.lbl_branch_no);
            this.Name = "stored_procedures";
            this.Text = "stored_procedures";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_branch_no;
        private System.Windows.Forms.TextBox txt_branchno;
        private System.Windows.Forms.Label lbl_street;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_street;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.TextBox txt_postcode;
        private System.Windows.Forms.Button btn_submit;
    }
}