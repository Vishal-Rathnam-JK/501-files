﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Entity_Framework_Implementation
{
    public partial class stored_procedures : Form
    {
        public stored_procedures()
        {
            InitializeComponent();
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            dream_homeEntities2 dbe = new dream_homeEntities2();
            string data = txt_branchno.Text;
            var res = dbe.disp_branch_bno(data).FirstOrDefault();
            if (res!=null)
            {
                txt_street.Text = res.street;
                txt_city.Text = res.city;
                txt_postcode.Text = res.postcode;
            }
            else
            {
                MessageBox.Show("No records found");
                txt_street.Text = "";
                txt_city.Text ="";
                txt_postcode.Text = "";
            }
            }
            
    }
}
