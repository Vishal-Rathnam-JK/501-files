﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace Entity_Framework_Implementation
{
    public partial class dropdown_display : Form
    {
        dream_homeEntities2 dbe;
        public dropdown_display()
        {
            InitializeComponent();
            dbe = new dream_homeEntities2();
        }

        private void dropdown_display_Load(object sender, EventArgs e)
        {
            var pop = dbe.branches.Select(d => d.branchno);
            foreach (var item in pop)
            {
                combo_branch.Items.Add(item);
            }
        }

        private void combo_branch_SelectedIndexChanged(object sender, EventArgs e)
        {
           // var res = dbe.branches.Where(d => d.branchno == combo_branch.Text).Select(d => new { d.branchno, d.city, d.street, d.postcode });
          //  dataGrid1.DataSource = res.ToList();
            dataGrid1.DataSource = dbe.branches.Where(d => d.branchno == combo_branch.Text).Select(d => new { d.branchno, d.city, d.street, d.postcode }).ToList();
        }
    }
}
