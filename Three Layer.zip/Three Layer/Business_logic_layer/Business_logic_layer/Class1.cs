﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using My_first_library;

namespace Business_logic_layer
{
    public class Class1
    {
        public string create_new_brno()
        {
            string new_br_no; 
        max_brno mbr = new max_brno();
        string old_max_brno = mbr.get_max_brno();
        int old_brno = int.Parse(old_max_brno.Substring(1, 3));
        if (old_brno<9)
        {
            int br_no = old_brno + 1;
            new_br_no = old_max_brno.Substring(0, 3) + br_no;
        }
        else if (old_brno >9 && old_brno <99)
        {
           int br_no = old_brno + 1;
            new_br_no = old_max_brno.Substring(0, 2) + br_no; 
        }
        else
        {
            int br_no = old_brno + 1;
            new_br_no = old_max_brno.Substring(0, 1) + br_no; 
        }
        return new_br_no;
            
        }
        public int save_into_db(string branch,string street,string city,string postcode)
        {
            max_brno mbr = new max_brno();
            return mbr.insert_branch(branch, street, city, postcode);                 
        }
    }
}
