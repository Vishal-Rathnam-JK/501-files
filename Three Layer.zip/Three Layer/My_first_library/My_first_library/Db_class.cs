﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace My_first_library
{
   public class Db_class
    {
        public DataSet show_record()
        {
            string constring = "server = PC251462 ;database=dream_home;integrated security=false;user id=sa;password=password-1";
            string query = "select * from propertyforrent";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return (ds);
        }
    }
}
