﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace My_first_library
{
    public class max_brno
    {
        public string get_max_brno()
        {
            string constring = "server=pc251462;database=dream_home;integrated security=false;user id=sa;password=password-1";
            string query = "select max(branchno) from branch";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            return ((string)cmd.ExecuteScalar());
        }
        public int insert_branch(string bno, string street, string cty, string pin)
        {
            string constring = "server=pc251462;database=dream_home;integrated security=false;user id=sa;password=password-1";
            string query = "insert into branch values(@bno,@str,@cty,@pin)";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd=new SqlCommand(query,con);
            SqlParameter bno_parm = cmd.Parameters.Add("@bno", SqlDbType.VarChar, 5);
            SqlParameter str_parm = cmd.Parameters.Add("@str", SqlDbType.VarChar, 15);
            SqlParameter cty_parm = cmd.Parameters.Add("@cty", SqlDbType.VarChar, 25);
            SqlParameter pin_parm = cmd.Parameters.Add("@pin", SqlDbType.VarChar, 10);
            bno_parm.Value = bno;
            str_parm.Value = street;
            cty_parm.Value = cty;
            pin_parm.Value = pin;
            return cmd.ExecuteNonQuery();
            
        }
    }
}
