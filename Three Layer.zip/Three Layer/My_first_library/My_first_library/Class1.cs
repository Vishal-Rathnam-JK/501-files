﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_first_library
{
    public class Class1
    {
        public string display_welcome()
        {
            return ("Welcome User");
        }
    }
}
