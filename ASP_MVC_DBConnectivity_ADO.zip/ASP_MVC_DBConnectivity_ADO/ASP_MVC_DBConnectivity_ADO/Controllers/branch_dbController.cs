﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASP_MVC_DBConnectivity_ADO.Models;
using ASP_MVC_DBConnectivity_ADO.Repository;

namespace ASP_MVC_DBConnectivity_ADO.Controllers
{
    public class branch_dbController : Controller
    {
        //
        // GET: /branch_db/

        public ActionResult get_all_branch()
        {
            branch_repository brep = new branch_repository();
            return View(brep.get_all_branch());
        }
        public ActionResult accept_branch()
        {
            return View();
        }
        public ActionResult save_branch(branch_model bmod)
        {
            branch_repository brep = new branch_repository();
            //if (brep.insert_branch(bmod))
            //{

            //    ViewBag.information = "records inserted successfully";
            //}
            //else
            //{
            //    ViewBag.information = "insertion failed";

            //}
            if (brep.insert_branch(bmod))
            {

                return RedirectToAction("get_all_branch");
            }
            else
            {
                ViewBag.information = "insertion failed";
                return View();

            }
           
        }
        //public ActionResult delete_branch()
        //{
        //    return View();
        //}

        public ActionResult delete_branch(string bno)
        {
            branch_repository brep = new branch_repository();
            if (brep.delete_branch(bno))
            {

                ViewBag.information = "record deleted successfully";
               return RedirectToAction("get_all_branch");
            }
            else
            {
                ViewBag.information = "deletion failed";
                return View();  
            }
                     
        }



        public ActionResult del_result(FormCollection fc)
        {
            branch_repository brep = new branch_repository();
            if (brep.delete_branch(fc["txt_branch_no"]))
            {

                ViewBag.information = "record deleted successfully";
            }
            else
            {
                ViewBag.information = "deletion failed";

            }
            return View();
        }

        public ActionResult get_branch(string branch_no)
        {
            branch_repository brep = new branch_repository();
            branch_model bmod = brep.show_branch(branch_no);
            return View(bmod);
        }


        public ActionResult update_branch(string br_no)
        {
            branch_repository brep = new branch_repository();
            branch_model bmod = brep.show_branch(br_no);
            return View(bmod);
        }

        [HttpPost]
        public ActionResult update_branch(branch_model bmod)
        {
            branch_repository brep = new branch_repository();
            if (brep.update_branch(bmod))
            {
                return RedirectToAction("get_all_branch");
            }
            else
            {
                return View();
            }
        }
    }
}
