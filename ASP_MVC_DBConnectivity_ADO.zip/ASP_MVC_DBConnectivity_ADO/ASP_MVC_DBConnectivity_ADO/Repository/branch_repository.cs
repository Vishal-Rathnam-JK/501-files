﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ASP_MVC_DBConnectivity_ADO.Models;

namespace ASP_MVC_DBConnectivity_ADO.Repository
{
    public class branch_repository
    {
        SqlConnection con;
        SqlCommand cmd;
        private void connect()
        {
            string constring = ConfigurationManager.ConnectionStrings["dream_home_connection"].ConnectionString;
            con = new SqlConnection(constring);
        }
        public List<branch_model> get_all_branch()
        {
            connect();
            List<branch_model> branch = new List<branch_model>();
            string query = "select * from branch";
            cmd = new SqlCommand(query, con);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            foreach (DataRow item in dt.Rows)
            {
                branch.Add(new branch_model { branch_no = item[0].ToString(), street = item[1].ToString(), city = item[2].ToString(), postcode = item[3].ToString() });
            }
            return branch;
        }
        public bool insert_branch(branch_model bmod)
        {
            connect();
            con.Open();
            string query = "insert into branch values(@branchno,@street,@city,@postcode)";
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@branchno", bmod.branch_no);
            cmd.Parameters.AddWithValue("@street", bmod.street);
            cmd.Parameters.AddWithValue("@city", bmod.city);
            cmd.Parameters.AddWithValue("@postcode", bmod.postcode);
            int result = cmd.ExecuteNonQuery();
            if (result==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool delete_branch(string branch_no)
        {
            connect();
            con.Open();
            string query = "delete from branch where branchno=@branchno";
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@branchno",branch_no);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public branch_model show_branch(string br_no)
        {
            
            branch_model br_model = new branch_model();
            connect();
            con.Open();
            string query = "select * from branch where branchno=@branchno";
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@branchno", br_no);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                br_model.branch_no = (string)dr[0];
                br_model.street = (string)dr[1];
                br_model.city = (string)dr[2];
                br_model.postcode = (string)dr[3];
            }
            return br_model;
        }

        public bool update_branch(branch_model bmod)
        {
            branch_model br_model = new branch_model();
            connect();
            con.Open();
            string query = "update branch set street=@street,city=@city,postcode=@postcode where branchno=@branchno";
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            cmd.Parameters.AddWithValue("@branchno", bmod.branch_no);
            cmd.Parameters.AddWithValue("@street", bmod.street);
            cmd.Parameters.AddWithValue("@city", bmod.city);
            cmd.Parameters.AddWithValue("@postcode", bmod.postcode);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}