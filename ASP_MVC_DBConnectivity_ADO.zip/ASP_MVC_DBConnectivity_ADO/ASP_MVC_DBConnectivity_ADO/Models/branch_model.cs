﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ASP_MVC_DBConnectivity_ADO.Models
{
    public class branch_model
    {
        [Key]
        public string branch_no { get; set; }
        public string street { get; set; }
        public string city { get; set; }
        public string postcode { get; set; }
    }
}