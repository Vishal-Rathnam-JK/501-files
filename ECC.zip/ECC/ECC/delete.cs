﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ECC
{
    class delete:user
    {
        public void deleteteam()
        {
            if (team_list.Count == 0)
            {
                Console.WriteLine("There are no teams");
                Thread.Sleep(1000);

            }
            else
            {


                Console.WriteLine("Select the team to be deleted");
                int numberlist = 1; //Used to list the teams in a numbered list           
                foreach (teams item in team_list)
                {
                    Console.WriteLine(numberlist + "." + item.team_name);
                    numberlist++;
                }
                int choice = int.Parse(Console.ReadLine());
                // Handling invalid choice  
                if (choice >= numberlist || choice == 0)
                {
                    Console.WriteLine("Choose the correct team");
                }
                // Removing selected teams 
                else
                {
                    string temp_team = team_list[choice - 1].team_name;
                    team_list.RemoveAt(choice - 1);
                    teams.number_of_teams--;
                    Console.WriteLine(temp_team + " has been deleted");
                    Thread.Sleep(1000);
                }
                // For further deletion
                Console.WriteLine("Do you still want to delete?\n1.yes\n2.no");
                int b = int.Parse(Console.ReadLine());
                if (b == 1)
                {
                    deleteteam();
                }
            }
        }
    }
}
