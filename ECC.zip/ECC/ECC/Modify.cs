﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ECC
{
    class Modify:user
    {
        int dup_team = 0;//Used to identify duplicate teams .... 1 for duplicate ..... 0 for unique 
        string temp_team_name;// Used to store the new team's name and check if it is a duplicate 
        int choice;
        //      Choosing the team to modify
        public void modifyteam()
        {
            if (team_list.Count == 0)
            {
                Console.WriteLine("List is empty , no teams to modify");                
            }
            else
            {


                Console.WriteLine("Select the team to be modified");
                int numberlist = 1;// Used to list out the teams as a numbered list
                foreach (teams item in team_list)
                {
                    Console.WriteLine(numberlist + "." + item.team_name);
                    numberlist++;
                }
                choice = int.Parse(Console.ReadLine());
                Console.WriteLine("This is the existing info:");
                Console.WriteLine("Team Name: " + team_list[choice - 1].team_name);
                Console.WriteLine("Team Group: " + team_list[choice - 1].team_group);
                Console.WriteLine("Team Captain: " + team_list[choice - 1].team_captain);
                Console.WriteLine("Which do u want to change?\n1.Team Name\n2.Team's Group\n3.Team's Captain");
                int mod_choice = int.Parse(Console.ReadLine());
                specificmod(mod_choice);
            }
        }
        //         Choosing the value of the team to modify
        public void specificmod(int mod_choice)
        {                       
            if (mod_choice==1)
            {
                do
                {
                    Console.Write("Enter the new Name for the team :");
                    temp_team_name = Console.ReadLine();
                    check_team(temp_team_name);  
                } while (dup_team!=0);
                team_list[choice - 1].team_name = temp_team_name;
            }
            else if (mod_choice==2)
            {
                Console.WriteLine("Choose the Team's Group :\n1.South Group\n2.North Group\n3.Midlands/Wales Group");
                int group_choice = int.Parse(Console.ReadLine());
                if (group_choice==1)
                {
                    team_list[choice - 1].team_group = "South Group";
                }
                else if (group_choice==2)
                {
                    team_list[choice - 1].team_group = "North Group";
                }
                else if (group_choice==3)
                {
                    team_list[choice - 1].team_group = "Midlands/Wales Group";
                }
                else
                {
                    Console.WriteLine("Invalid choice , Group remains unchanged");
                }
               
            }
            else if (mod_choice==3)
            {
                Console.Write("Enter the name of the Team's new Captain:");
                team_list[choice - 1].team_captain = Console.ReadLine();
            }
            // Displaying the modified details 
            Console.WriteLine("This is the modified Details of the team");
            Console.WriteLine("Team Name : "+team_list[choice-1].team_name);
            Console.WriteLine("Team Group : " + team_list[choice - 1].team_group);
            Console.WriteLine("Team Captain : " + team_list[choice - 1].team_captain);
            int further_mod_choice;
            do
            {
                Console.WriteLine("Do you want to modify further?\n1.Yes2.No");
                further_mod_choice = int.Parse(Console.ReadLine());
                if (further_mod_choice==1)
                {
                    Console.WriteLine("Which do u want to change?\n1.Team Name\n2.Team's Group\n3.Team's Captain");
                    mod_choice = int.Parse(Console.ReadLine());
                    specificmod(mod_choice); 
                }
                else if (further_mod_choice==2)
                {
                    Console.WriteLine("The team details have been modified");
                }
                else
                {
                    Console.WriteLine("Invalid option");
                }
            } while (further_mod_choice==3);  //Done atleast once , exited if choice is other than 1(yes) or 2(no)                                                                         
        }
    
        //       To avoid the addition of duplicate teams  
        public void check_team(string team_name)
        {
            foreach (teams item in team_list)
            {
                if (team_name == item.team_name)
                {
                    dup_team = 1;
                    Console.WriteLine("Team Name already exists , choose a different name");
                    break;
                }
                else
                {
                    dup_team = 0;
                }
            }
        }
    }
}
