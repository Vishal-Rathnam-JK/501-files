﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ECC
{
    class print:user
    {
        public void printteam()
        {
//                           Creating a file that will be overwritten everytime
            FileStream out_file = new FileStream(@"D:\Case Study\Inputfile.csv", FileMode.Create, FileAccess.Write);
            StreamWriter write = new StreamWriter(out_file);
//                                    Handling empty list
            if (team_list.Count==0)
            {
                Console.WriteLine("There are no teams , Writing aborted");
            }
//                                    Writing onto the file
            else
            {
                write.WriteLine("Team Name,Team Group,Team Captain");
                foreach (teams team in team_list)
                {
                    write.WriteLine(team.team_name + "," + team.team_group + "," + team.team_captain);
                }
                Console.WriteLine("The Data is saved in the file\n\t\t\t\tThanks");
            }            
            write.Close();
            out_file.Close();
        }
    }
}
