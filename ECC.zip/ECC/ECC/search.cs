﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
namespace ECC
{
    class search:user
    {
        public void searchteam()
        {
            
            Console.WriteLine("Enter the team's name to be found");
            string Team_to_be_searched = Console.ReadLine();
            int teamfound = 0;  // Teamfound = 0 if team is present , 1 if not present
            foreach (teams item in team_list)
            {
                //Team found
                if (item.team_name.ToLower() ==  Team_to_be_searched.ToLower())
                {
                    Console.WriteLine(item.team_name+" is found");
                    Console.WriteLine("The team's details are:");
                    Console.WriteLine("Team name: "+item.team_name);
                    Console.WriteLine("Team's group: " + item.team_group);
                    Console.WriteLine("Team's captain: " + item.team_captain);
                    teamfound = 0;
                    Thread.Sleep(3000);
                    break;
                }
                else
                {
                    teamfound = 1;
                }
            }
            // Handling an empty list
            if (team_list.Count==0)
            {
                Console.WriteLine("The list is empty");
                Thread.Sleep(1000);
            }
                //Team not present
            else if (teamfound==1)
            {
                Console.WriteLine("team not found");
                teamfound = 0;
                Thread.Sleep(1000);
            }
        }
    }
}
