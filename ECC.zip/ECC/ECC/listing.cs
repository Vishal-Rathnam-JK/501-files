﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ECC
{
    class listing:user
    {
        int choice;
        int numberlist = 1; // Used to list out teams as a numbered list
        public void listteam()
        {   
            // Handling empty list     
            if (team_list.Count==0)
            {
                Console.WriteLine("There are no teams");
                Thread.Sleep(1000);
            }
            else
            {
                Console.WriteLine("Team List\n Which team do u want more information on ?");
                numberlist = 1;                    
                foreach (teams item in team_list)
                {
                    Console.WriteLine(numberlist + "." + item.team_name);
                    numberlist++;
                }
                Console.WriteLine(numberlist+".None");
                choice = int.Parse(Console.ReadLine());
                display();
                Thread.Sleep(1000);
            }
        }
        // Used to display further details for the selected team
        public void display()
        {
            if (choice==numberlist)
            {
                Console.WriteLine("End of List");
            }
            else if( choice >numberlist)
            {
                Console.WriteLine("Invalid Choice");
            }
            else
            {
                Console.WriteLine("Team Name : "+team_list[choice-1].team_name);
                Console.WriteLine("Team's Group : " + team_list[choice - 1].team_group);
                Console.WriteLine("Team's Captain : " + team_list[choice - 1].team_captain);
                Thread.Sleep(2000);
            }
        }
    }
}
