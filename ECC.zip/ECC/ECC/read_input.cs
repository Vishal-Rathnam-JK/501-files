﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ECC
{
    class read_input:user
    {
        public void fill_list()
        {
            int dup_team=0;//To avoid adding same teams multiple times
            FileStream input_file = new FileStream(@"D:\Case Study\Inputfile.csv", FileMode.Open, FileAccess.Read);
            StreamReader read = new StreamReader(input_file);
            string[] values;
            string null_check;// To Handle null exception while splitting
            do
            {
              null_check=read.ReadLine();
                if (null_check != null)
                {
                     values =  null_check.Split(',');
                     if (values[0]!="Team Name")
                     {
                         foreach (teams item in team_list)
                         {
 //                                     Group Integrity is also verified here 
                             if (values[0] == item.team_name || (values[1].ToLower() != "south group" && values[1].ToLower() != "north group" && values[1].ToLower() != "midlands/wales group"))
                             {
                                 dup_team = 1;
                             }                            
                         }
                         if (dup_team==0)
                         {
                             teams team_object = new teams();
                             team_object.team_name = values[0];
                             team_object.team_group = values[1];
                             team_object.team_captain = values[2];
                             team_list.Add(team_object);                             
                         }
                         dup_team = 0;
                    }
               }
            } while (null_check != null);           
            read.Close();
            input_file.Close();
        }
    }
}
