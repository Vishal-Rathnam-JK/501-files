﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECC
{
    class add:user
    {        
        int dup_team=0;//Used to identify duplicate teams .... 1 for duplicate ..... 0 for unique 
        public void addteam()
        {
            teams t = new teams();
            Console.WriteLine("\t\t\tAdd a new team");
            Console.WriteLine("Choose the team's group : \n1.South Group\n2.North Group\n3.Midlands/Wales Group");
            //            Groups can only be from the three
            int group_selector = int.Parse(Console.ReadLine());
            if (group_selector == 1)
            {
                t.team_group = "South Group";
                Console.Write("Team's Group : "+t.team_group);
                do
                {
                    Console.Write("\nEnter the team name : ");
                    t.team_name = Console.ReadLine();
                   check_team(t.team_name); 
                } while (dup_team!=0);
                               
                Console.Write("Enter the team captain : ");
                t.team_captain = Console.ReadLine();
                teams.number_of_teams++;
                team_list.Add(t);
            }
            else if (group_selector==2)
            {
                t.team_group = "North Group";
                Console.Write("Team's Group : " + t.team_group);
                do
                {
                    Console.Write("\nEnter the team name : ");
                    t.team_name = Console.ReadLine();
                    check_team(t.team_name); 
                } while (dup_team!=0);
                
                Console.Write("Enter the team captain : ");
                t.team_captain = Console.ReadLine();
                teams.number_of_teams++;
                team_list.Add(t);
            }
            else if (group_selector==3)
            {
                t.team_group = "Midlands/Wales Group";
                Console.Write("Team's Group : " + t.team_group);
                do
                {
                    Console.Write("\nEnter the team name : ");
                    t.team_name = Console.ReadLine();
                    check_team(t.team_name); 
                } while (dup_team!=0);
                
                Console.Write("Enter the team captain : ");
                t.team_captain = Console.ReadLine();
                teams.number_of_teams++;
                team_list.Add(t);
            }
            else
            {
                Console.WriteLine("Invalid Group Selected , please reselect");
                addteam();               
            }
                    
        }
        //       To avoid the addition of duplicate teams  
        public void check_team(string team_name)
        {
            foreach (teams item in team_list)
            {
                if (team_name==item.team_name)
                {
                    dup_team = 1;
                    Console.WriteLine("Team Name already exists , choose a different name");
                    break;
                }
                else
                {
                    dup_team=0;
                }
            }
        }

               
        }
    }


