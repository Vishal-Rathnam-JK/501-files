﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECC
{
    class user
    {
       public static List<teams> team_list = new List<teams>();
        public static void Main()
        {           
            select s = new select();
            s.selection();
        }
    }
}
