﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ECC
{
    class teams
    {
        public static int number_of_teams;
        public string team_name;
        public string team_group;
        public string team_captain;
    }
}
