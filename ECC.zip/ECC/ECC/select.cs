﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ECC
{
    class select
    {
        //int team_added = 0;//used to avoid repopulating the list with the same file
         read_input read = new read_input();            
        add add_object = new add();
        Modify modify_object = new Modify();
        search search_object = new search();
        delete delete_object = new delete();
        listing listing_object = new listing();
        print print_object = new print();
        public void selection()
        {            
            Console.Clear();
            Console.WriteLine("\t\t\t\tWelcome");
            Console.WriteLine("choose option\n1.Load data from the file\n2.Add Team\n3.Modify existing team\n4.Search Team\n5.Delete Team\n6.List all teams\n7.Save Changes to the existing File\n8.Exit without saving");
            int choice = int.Parse(Console.ReadLine());           
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Adding information from the list.....");
                    Thread.Sleep(1000);
                    read.fill_list();
                    Console.WriteLine("Information added");
                    Thread.Sleep(1000);
                    selection();
                    break;
                case 2:
                    Console.WriteLine("Proceeding to Add Menu");
                    Thread.Sleep(1000);
                    Console.Clear();
                    add_object.addteam();
                    Console.WriteLine("Team Added");
                    Thread.Sleep(1000);
                    selection();
                    break;
                case 3:
                    Console.WriteLine("Proceeding to Modify Menu");
                    Thread.Sleep(1000);
                    Console.Clear();
                    modify_object.modifyteam();
                    Thread.Sleep(2000);
                    selection();
                    break;
                case 4:
                    Console.WriteLine("Proceeding to Search Menu");
                    Thread.Sleep(2000);
                    Console.Clear();
                    search_object.searchteam();
                    selection();
                    break;
                case 5:
                    Console.WriteLine("Proceeding to Delete Menu");
                    Thread.Sleep(2000);
                    Console.Clear();
                    delete_object.deleteteam();
                    selection();
                    break;
                case 6:
                    Console.WriteLine("Proceeding to Display Menu");
                    Thread.Sleep(2000);
                    Console.Clear();
                    listing_object.listteam();
                    selection();
                    break;                
                case 7:
                    print_object.printteam();
                    Thread.Sleep(1000);
                    selection();
                    break;
                case 8:
                    Console.WriteLine("\t\t\t\tThanks");
                    break;
                default:
                    Console.WriteLine("Invalid Choice . Please choose again");
                    selection();
                    break;
            }
        } 
    }
}
