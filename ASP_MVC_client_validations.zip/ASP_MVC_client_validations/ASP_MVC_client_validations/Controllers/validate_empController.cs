﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASP_MVC_client_validations.Models;

namespace ASP_MVC_client_validations.Controllers
{
    public class validate_empController : Controller
    {
        //
        // GET: /validate_emp/

        public ActionResult accept_emp()
        {
            return View();
        }
        public ActionResult print_emp(employee emp)
        {
            return View();
        }

    }
}
