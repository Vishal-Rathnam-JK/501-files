﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ASP_MVC_client_validations.Models
{
    public class employee
    {
        [Required(ErrorMessage="Employee id should not be blank")]
        [Key]
        public int emp_id { get; set; }


        [Required(ErrorMessage="Employee name should not be blank")]
        //[DataType(DataType.Text,ErrorMessage="wrong")]
        public string emp_name { get; set; }


        [Required(ErrorMessage = "salary should not be empty")]
        [Range(0,50,ErrorMessage="Salary should be between 0 and 50")]
        public double emp_sal { get; set; }
    }
}