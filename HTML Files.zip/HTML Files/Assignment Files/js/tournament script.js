
//               SCRIPT FOR WICKET TAKERS STRIKE RATE CALCULATION   //


function calcbowlstrikerate()
{
//Highest//
var wic1=document.getElementById("wick1").innerText;
var ove1=document.getElementById("over1").innerText;          
var parts1 =ove1.split('.');
var i1 = parseInt(parts1[0]);
var i2 = parseInt(parts1[1]);        
var balls1 = i1 * 6 + i2;
var rate1 = balls1 / wic1;         
document.getElementById("strrate1").innerText=rate1.toFixed(2);
//Second highest//
var wic2=document.getElementById("wick2").innerText;
var ove2=document.getElementById("over2").innerText;          
var parts =ove2.split('.');
var i1 = parseInt(parts[0]);
var i2 = parseInt(parts[1]);        
var balls2 = i1 * 6 + i2;
var rate2 = balls2 / wic2;         
document.getElementById("strrate2").innerText=rate2.toFixed(2);
//Third highest//
var wic2=document.getElementById("wick3").innerText;
var ove2=document.getElementById("over3").innerText;          
var parts =ove2.split('.');
var i1 = parseInt(parts[0]);
var i2 = parseInt(parts[1]);        
var balls2 = i1 * 6 + i2;
var rate2 = balls2 / wic2;         
document.getElementById("strrate3").innerText=rate2.toFixed(2);
//Fourth Highest//
var wic2=document.getElementById("wick4").innerText;
var ove2=document.getElementById("over4").innerText;          
var parts =ove2.split('.');
var i1 = parseInt(parts[0]);
var i2 = parseInt(parts[1]);        
var balls2 = i1 * 6 + i2;
var rate2 = balls2 / wic2;         
document.getElementById("strrate4").innerText=rate2.toFixed(2);
//Fifth Highest//
var wic2=document.getElementById("wick5").innerText;
var ove2=document.getElementById("over5").innerText;          
var parts =ove2.split('.');
var i1 = parseInt(parts[0]);
var i2 = parseInt(parts[1]);        
var balls2 = i1 * 6 + i2;
var rate2 = balls2 / wic2;         
document.getElementById("strrate5").innerText=rate2.toFixed(2);
}


//                 SCRIPT FOR TOP SCORERS STRIKE RATE CALCULATION                //


function calcbatstrikerate()
{
var run1=document.getElementById("run1").innerText;
var inn1=document.getElementById("inn1").innerText;
var avg1=run1/inn1;
document.getElementById("avg1").innerText=avg1.toFixed(2);
var run2=document.getElementById("run2").innerText;
var inn2=document.getElementById("inn2").innerText;
var avg2=run2/inn2;
document.getElementById("avg2").innerText=avg2.toFixed(2);
var run3=document.getElementById("run3").innerText;
var inn3=document.getElementById("inn3").innerText;
var avg3=run3/inn3;
document.getElementById("avg3").innerText=avg3.toFixed(2);
var run4=document.getElementById("run4").innerText;
var inn4=document.getElementById("inn4").innerText;
var avg4=run4/inn4;
document.getElementById("avg4").innerText=avg4.toFixed(2);
var run5=document.getElementById("run5").innerText;
var inn5=document.getElementById("inn5").innerText;
var avg5=run5/inn5;
document.getElementById("avg5").innerText=avg5.toFixed(2);
}


     
//                             SCRIPT FOR NORTH TEAMS                       //



function northdetail()
{
var t=team.value;
if(t=="durh")
{
document.getElementById("dis").innerHTML=document.getElementById("dur").innerHTML;
}
else if(t=="nott")
{
document.getElementById("dis").innerHTML=document.getElementById("not").innerHTML;
}
else if(t=="york")
{
document.getElementById("dis").innerHTML=document.getElementById("yor").innerHTML;
}
else if(t=="derb")
{
document.getElementById("dis").innerHTML=document.getElementById("der").innerHTML;
}
else if(t=="select")
{
document.getElementById("dis").innerHTML=document.getElementById("sel").innerHTML;
}
}




//                               SCRIPT FOR WALES TEAMS                          //



function walesdetail()
{
var t=team.value;
if(t=="some")
{
document.getElementById("dis").innerHTML=document.getElementById("som").innerHTML;
}
else if(t=="warw")
{
document.getElementById("dis").innerHTML=document.getElementById("war").innerHTML;
}
else if(t=="worc")
{
document.getElementById("dis").innerHTML=document.getElementById("wor").innerHTML;
}
else if(t=="nort")
{
document.getElementById("dis").innerHTML=document.getElementById("nor").innerHTML;
}
else if(t=="glou")
{
document.getElementById("dis").innerHTML=document.getElementById("glo").innerHTML;
}
else if(t=="glam")
{
document.getElementById("dis").innerHTML=document.getElementById("gla").innerHTML;
}
else if(t=="select")
{
document.getElementById("dis").innerHTML=document.getElementById("sel").innerHTML;
}
}




//                            SCRIPT FOR SOUTH TEAMS                                         //



function southdetail()
{
var t=team.value;
if(t=="hamp")
{
document.getElementById("dis").innerHTML=document.getElementById("ham").innerHTML;
}
else if(t=="suss")
{
document.getElementById("dis").innerHTML=document.getElementById("sus").innerHTML;
}
else if(t=="surr")
{
document.getElementById("dis").innerHTML=document.getElementById("sur").innerHTML;
}
else if(t=="midd")
{
document.getElementById("dis").innerHTML=document.getElementById("mid").innerHTML;
}
else if(t=="esse")
{
document.getElementById("dis").innerHTML=document.getElementById("ess").innerHTML;
}
else if(t=="kent")
{
document.getElementById("dis").innerHTML=document.getElementById("ken").innerHTML;
}
else if(t=="select")
{
document.getElementById("dis").innerHTML=document.getElementById("sel").innerHTML;
}
}