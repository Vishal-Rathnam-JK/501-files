﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace First_application
{
    public partial class Web_Service_Call : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_convert_Click(object sender, EventArgs e)
        {
            Currency_Converter_service_reference.Service1SoapClient sref = new Currency_Converter_service_reference.Service1SoapClient();
            int dollar_value = Int32.Parse(txt_dollar.Text);
            txt_rupees.Text = sref.dollar_to_rs(dollar_value).ToString();
        }
    }
}