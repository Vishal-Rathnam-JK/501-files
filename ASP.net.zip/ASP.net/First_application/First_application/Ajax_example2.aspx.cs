﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace First_application
{
    public partial class Ajax_example2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                dropdown_state.Items.Add("--Select--");
                dropdown_state.Items.Add("Tamilnadu");
                dropdown_state.Items.Add("Kerala");
            }
        }

        protected void dropdown_state_SelectedIndexChanged(object sender, EventArgs e)
        {
            dropdown_city.Items.Clear();
            if (dropdown_state.Text=="Tamilnadu")
            {               
                dropdown_city.Items.Add("--Select--");
                dropdown_city.Items.Add("Chennai");
                dropdown_city.Items.Add("Kaaraikudi");
            }
            else if (dropdown_state.Text=="Kerala")
            {              
                dropdown_city.Items.Add("--Select--");
                dropdown_city.Items.Add("Palakkad");
                dropdown_city.Items.Add("Cochin");
            }
        }

        protected void dropdown_city_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}