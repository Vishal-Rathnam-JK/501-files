﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace First_application
{
    public partial class first_form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label3.Visible = false;
            Label4.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
           // Response.Write("hi");
           // Response.Redirect("second_form.aspx");
            if (txt_username.Text.Length==0)
            {
                Label3.Visible = true;
            }
            if (txt_password.Text.Length==0)
            {
                Label4.Visible = true;
            }
            if (txt_username.Text.Length!=0 && txt_password.Text.Length!=0 )
            {
                Label3.Visible = false;
                Label4.Visible = false;
                Response.Write("hi "+txt_username.Text);
            }
        }
    }
}