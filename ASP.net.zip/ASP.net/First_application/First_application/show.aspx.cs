﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace First_application
{
    public partial class show : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txt_name.Text = Request.QueryString["uname"].ToString();
            txt_age.Text = Request.QueryString["age"].ToString();
        }
    }
}