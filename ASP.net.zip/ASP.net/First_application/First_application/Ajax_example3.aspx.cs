﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;

namespace First_application
{
    public partial class Ajax_example3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_add_Click(object sender, EventArgs e)
        {
            Thread.Sleep(5000);
            Label3.Text = (Int32.Parse((txt_1.Text)) + Int32.Parse((txt_2.Text))).ToString();
        }
    }
}