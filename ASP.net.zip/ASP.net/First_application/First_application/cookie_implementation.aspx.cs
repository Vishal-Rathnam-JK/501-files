﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace First_application
{
    public partial class cookie_implementation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_store_Click(object sender, EventArgs e)
        {
            HttpCookie hc = new HttpCookie("mydata");
            hc["uname"] = txt_name.Text;
            hc["age"] = txt_age.Text;
            hc.Expires.AddHours(2);
            Response.Cookies.Add(hc);
            txt_name.Text = string.Empty;
            txt_age.Text = string.Empty;
        }

        protected void btn_retrieve_Click(object sender, EventArgs e)
        {
            HttpCookie hp = Request.Cookies["mydata"];
            if (hp!=null)
            {
                txt_name.Text = hp["uname"].ToString();
                txt_age.Text = hp["age"].ToString();
            }
        }

        protected void btn_transfer_Click(object sender, EventArgs e)
        {
            Response.Redirect("show.aspx?uname=" + txt_name.Text + "&age=" + txt_age.Text);
        }
    }
}