﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace First_application
{
    [Serializable]
     public class product
        {
         public int prod_id;
         public string prod_name;
        }
    public partial class server_session_management : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_store_Click(object sender, EventArgs e)
        {
            product p = new product();
            p.prod_id = Int32.Parse(txt_prod_id.Text);
            p.prod_name = txt_prod_name.Text;
            Session["prod_details"] = p;
            txt_prod_name.Text = string.Empty;
            txt_prod_id.Text = string.Empty;
        }
        protected void btn_retrieve_Click(object sender, EventArgs e)
        {
            product p = (product)Session["prod_details"];
            txt_prod_name.Text = p.prod_name;
            txt_prod_id.Text = p.prod_id.ToString();
        }
    }
}