﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace First_application
{
    public partial class Session_management : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_change_Click(object sender, EventArgs e)
        {
            Label1.Text = "Thanks";
            Label2.Text = "Thanks";
        }
    }
}