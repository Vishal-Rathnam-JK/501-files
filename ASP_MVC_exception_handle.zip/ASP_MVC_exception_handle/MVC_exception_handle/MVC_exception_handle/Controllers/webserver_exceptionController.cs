﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_exception_handle.Controllers
{
    public class webserver_exceptionController : Controller
    {
        //
        // GET: /webserver_exception/
        [HandleError]
        public ActionResult Index()
        {
            throw new Exception("some error has occured");
        }

        public ActionResult Index1()
        {
            throw new Exception("some error has occured");
        }

    }
}
