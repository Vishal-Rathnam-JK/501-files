﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_exception_handle.Controllers
{
    public class exception_handleController : Controller
    {
        //
        // GET: /exception_handle/

        public ActionResult Index()
        {
            int z;
            try
            {
                int x = 10;
                int y = 0;
                z = x / y;
            }
            catch (Exception )
            {

                throw new Exception();
            }
            

            return Content("The output is "+z);
        }

    }
}
