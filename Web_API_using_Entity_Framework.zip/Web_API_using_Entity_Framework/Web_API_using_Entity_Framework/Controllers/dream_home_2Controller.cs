﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API_using_Entity_Framework.Models;

namespace Web_API_using_Entity_Framework.Controllers
{
    public class dream_home_2Controller : ApiController
    {
        dream_homeEntities dhe = new dream_homeEntities();

        [HttpGet]
        public List<string> populate_all_branch()
        {
            return dhe.branches.Select(i => i.branchno).ToList();
        }
    }
}
