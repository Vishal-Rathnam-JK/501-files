﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Web_API_using_Entity_Framework.Controllers
{
    public class dream_home_mvcController : Controller
    {
        //
        // GET: /dream_home_mvc/

        public ActionResult Index()
        {
            return View();
        }


        public ActionResult add_branch()
        {
            return View();      
        }

        public ActionResult update_branch()
        {
            return View();        
        }

        
    }
}
