﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API_using_Entity_Framework.Models;

namespace Web_API_using_Entity_Framework.Controllers
{
    public class dream_home_apiController : ApiController
    {
        dream_homeEntities dhe = new dream_homeEntities();
        [HttpGet]
        public List<branch> get_all_branch()
        {
            return dhe.branches.ToList();
        }

        [HttpPost]
        public int insert_branch(branch br)
        {
            dhe.branches.Add(br);
            return dhe.SaveChanges();
        }

        [HttpPut]
        public int update_branch(branch br)
        {
            branch b = dhe.branches.Find(br.branchno);
            //branch bran = dhe.branches.Where(i => i.branchno == br.branchno).FirstOrDefault();
            b.city = br.city;
            b.street = br.street;
            b.postcode = br.postcode;
            return dhe.SaveChanges();
        }


        [HttpGet]
        public List<string> populate_all_branch()
        {
            return dhe.branches.Select(i=>i.branchno).ToList();
        }
    }
}
