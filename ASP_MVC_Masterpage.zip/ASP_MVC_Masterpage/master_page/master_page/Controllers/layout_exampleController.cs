﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace master_page.Controllers
{
    public class layout_exampleController : Controller
    {
        //
        // GET: /layout_example/

        public ActionResult home()
        {
            return View("home");
        }

        public ActionResult about()
        {
            return View("about");
        }
        public ActionResult fb()
        {
            return View("fb");
        }
        public ActionResult twitter()
        {
            return View("twitter");
        }

    }
}
