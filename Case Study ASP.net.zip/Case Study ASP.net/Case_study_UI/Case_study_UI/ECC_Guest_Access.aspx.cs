﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using Case_study_Business_layer;

namespace Case_study_UI
{
    public partial class ECC_Page1 : System.Web.UI.Page
    {
        BAL_Class bal_obj = new BAL_Class();
        protected void Page_Load(object sender, EventArgs e)
        {                       
            if (!Page.IsPostBack)
            {
                ddlist_team.Items.Add("--Select--");
                ddlist_group.Items.Add("--Select--");
// populating the group selection drop down list
                foreach (string item in bal_obj.group_populate())
                {
                    ddlist_group.Items.Add(item);
                }               
            }                           
        }

// Function for auto complete
        [WebMethod]
        public static string[] getteam(string team)
        {
            BAL_Class bal_obj = new BAL_Class();
            return bal_obj.getteam(team);
        }


        protected void ddlist_team_SelectedIndexChanged1(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {
// setting the label's visibiity to true only if a team is selected
                txt_search.Text = string.Empty;
                lbl_gridview_heading.Visible = true;
                if (ddlist_team.Text!="--Select--")
                {
                    lbl_gridview_heading.Text = "Matches Played by " + ddlist_team.Text; 
                }
                else
                {
                    lbl_gridview_heading.Visible = false;
                }
 // populating the grid view based on team selected drop down list              
                gridview_team_details.Visible = true;
                gridview_team_details.DataSource = bal_obj.detailspopulate(ddlist_team.Text);
                gridview_team_details.DataBind();
            }           
        }

// Action for group index changed , thereby selecting only the teams in the group
        protected void ddlist_group_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_search.Text = string.Empty;
            lbl_gridview_heading.Visible = false;
            gridview_team_details.Visible = false;                        
            ddlist_team.Items.Clear();
            ddlist_team.Items.Add("--Select--");
            foreach (string item in bal_obj.team_populate(ddlist_group.Text))
            {
                ddlist_team.Items.Add(item);
            }
        }
        protected void ddlist_team_TextChanged(object sender, EventArgs e)
        {
           
        }
// Action for admin login button click
        protected void btn_adminlogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("ECC_Admin_login");
        }
// Action for Search button click
        protected void btn_search_Click(object sender, EventArgs e)
        {
            if (txt_search.Text!="" || txt_search.Text!="No results found.")
            {
                ddlist_group.SelectedValue = "--Select--";
                ddlist_team.SelectedValue = "--Select--";                                                                         
                    // setting the label's visibiity to true only if a team is selected
                      lbl_gridview_heading.Visible = true;
                        lbl_gridview_heading.Text = "Matches Played by " + txt_search.Text;
                        // populating the grid view based on team selected drop down list              
                        gridview_team_details.Visible = true;
                        gridview_team_details.DataSource = bal_obj.detailspopulate(txt_search.Text);
                        gridview_team_details.DataBind();
                        if (gridview_team_details.Rows.Count==0)
                        {
                            lbl_gridview_heading.Visible = false;
                        }                                                 
            }
            else
            {
                lbl_gridview_heading.Visible = false;
            }
        }

        
    }
}