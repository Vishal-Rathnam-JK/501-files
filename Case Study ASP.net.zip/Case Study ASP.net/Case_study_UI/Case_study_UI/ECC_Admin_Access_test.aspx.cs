﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Case_study_Business_layer;
namespace Case_study_UI
{
    public partial class ECC_Admin_Access : System.Web.UI.Page
    {
        BAL_Class bal_obj = new BAL_Class();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddl_tables.Items.Add("--Select--");
                ddl_tables.Items.Add("team_details");
                ddl_tables.Items.Add("venue_details");
                ddl_tables.Items.Add("match_details");
                ddl_tables.Items.Add("match_result");
                ddl_tables.Items.Add("scorecard");
                gridview_table.Visible = false;
           }          
        }

        protected void ddl_tables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_tables.Text != "--Select--")
            {
                gridview_table.Visible = true;
                gridview_table.DataSource = bal_obj.db_table_populate(ddl_tables.Text);
                gridview_table.DataBind();
            }
            else
            {
                gridview_table.Visible = false;
            }
        }

        protected void gridview_table_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string team = (gridview_table.Rows[e.RowIndex].FindControl("lbl_team") as TextBox).Text;
            string group = (gridview_table.Rows[e.RowIndex].FindControl("lbl_team") as DropDownList).SelectedValue;
            gridview_table.EditIndex = -1;

        }

        protected void gridview_table_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void gridview_table_RowEditing(object sender, GridViewEditEventArgs e)
        {
           gridview_table.EditIndex = e.NewEditIndex;
           gridview_table.DataSource = bal_obj.db_table_populate(ddl_tables.Text);
           gridview_table.DataBind();
        }

        protected void gridview_table_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridview_table.EditIndex = -1;
        }
    }
}