﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Case_study_Business_layer;

namespace Case_study_UI
{
    public partial class ECC_Admin_Access_try : System.Web.UI.Page
    {
        BAL_Class bal_obj = new BAL_Class();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddl_tables.Items.Add("--Select--");
                foreach (string item in bal_obj.ddl_table_populate())
                {
                    ddl_tables.Items.Add(item);
                }              
            }     
        }
        protected void ddl_tables_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Initially set all dataviews' visibility to false , inside if condition set only the necessary dataview's visibility to true
            detailview_team_details.Visible = false;
            detailview_venue.Visible = false;
            detailview_match_details.Visible = false;
            detailview_match_result.Visible = false;
            detailview_scorecard.Visible = false;
            if (ddl_tables.Text=="team_details")
            {
                detailview_team_details.Visible = true;
            }
            if (ddl_tables.Text=="venue_details")
            {
                detailview_venue.Visible = true;
            }
            if (ddl_tables.Text=="match_details")
            {
                detailview_match_details.Visible = true;
            }
            if (ddl_tables.Text == "match_result")
            {
                detailview_match_result.Visible = true;
            }
            if (ddl_tables.Text=="scorecard")
            {
                detailview_scorecard.Visible = true;
            }   
        }
        protected void btn_home_Click(object sender, EventArgs e)
        {
            Response.Redirect("ECC_Guest_Access.aspx");
        }
    }
}