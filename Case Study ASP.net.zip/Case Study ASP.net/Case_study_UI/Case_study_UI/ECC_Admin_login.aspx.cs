﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Case_study_UI
{
    public partial class ECC_Admin_login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // Action for continue as guest button click
        protected void btn_guest_Click(object sender, EventArgs e)
        {
            Response.Redirect("ECC_Guest_Access.aspx");
        }

        protected void btn_sign_in_Click(object sender, EventArgs e)
        {
            
        }
        // Action for sign in button click
        protected void btn_sign_in_Click1(object sender, EventArgs e)
        {
            Response.Redirect("ECC_Admin_Access.aspx");
        }
    }
}