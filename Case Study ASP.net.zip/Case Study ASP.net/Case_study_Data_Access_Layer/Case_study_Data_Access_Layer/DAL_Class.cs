﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Case_study_Data_Access_Layer
{
    public class DAL_Class
    {
// declaring a common query string , parameter list to be passed to the datareader or dataadapter function                
        string query;
        List<SqlParameter> parmlist;
// declaring a common object for the class containing data access functions
        dal_functions data_access = new dal_functions();

// function to populate the group dropdown list
        public DataSet grouppopulate()
        {          
            query="select distinct team_group from team_details";                       
            return data_access.adapterread(query, null);           
        }
//function for search bar
        public string[] getteam(string team)
        {
            query = "select team from team_details where team like '%" + team + "%'";
            List<string> team_list = new List<string>();
            SqlDataReader read = data_access.datareader_read(query, null);
            while (read.Read())
            {
                team_list.Add(read.GetString(0));
            }
            return team_list.ToArray();
        }
// function to populate the teams dropdown lsit
        public List<string> teampopulate(string group)
        {
            List<string> team_list = new List<string>();            
            query = "select distinct team from team_details where team_group=@group";
            parmlist = new List<SqlParameter>();
            SqlParameter group_name = new SqlParameter("@group", SqlDbType.VarChar, 25);
            group_name.Value = group;
            parmlist.Add(group_name);
            SqlDataReader read_teams = data_access.datareader_read(query,parmlist);
            while (read_teams.Read())
            {
                team_list.Add(read_teams[0].ToString());
            }
            return team_list;
        }

// function to populate the gridview for selected team
        public DataSet detailspopulate(string team)
        {                                          
             query = "select series_id,match_details.match_id,match_date,match_venue,home,away,result from match_details join match_result on match_details.match_id=match_result.match_id where home=@team or away=@team2";           
             parmlist = new List<SqlParameter>();           
            SqlParameter parm1 = new SqlParameter("@team", SqlDbType.VarChar, 25);
            parm1.Value = team;
           SqlParameter parm2 = new SqlParameter("@team2", SqlDbType.VarChar, 25);
            parm2.Value = team;
            parmlist.Add(parm1);
            parmlist.Add(parm2);                                              
            return data_access.adapterread(query, parmlist);
        }

// function to populate the gridview with the table from database of admin's choice
        public DataSet db_table_populate(string table)
        {
            query = "select * from "+table;                                                          
            return data_access.adapterread(query, null);
        }

// function to populate table dropdown list in admin page

        public DataSet table_dropdown_populate()
        {
            query = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' and TABLE_NAME<>'sysdiagrams'";
            return data_access.adapterread(query, null); 
        }
    }

// class containing data access functions
    public class dal_functions
    {
// declaring a common connection object and command object
        SqlConnection con = new SqlConnection("server=pc251462;database=t20;integrated security=false;user id=sa;password=password-1");
        SqlCommand cmd;

// function for reading using data adapter which returns a dataset
        public DataSet adapterread(string query, List<SqlParameter> parameters)
        {           
          con.Open();
            cmd= new SqlCommand(query, con);
            if (parameters!=null)
            {
                foreach (SqlParameter item in parameters)
                {
                    cmd.Parameters.Add(item);
                } 
            }                       
           SqlDataAdapter detailadapter = new SqlDataAdapter(cmd);
            DataSet details = new DataSet();
            detailadapter.Fill(details, "team details");
            return details;            
        }

// function for reading using a data reader which returns a datareader 
        public SqlDataReader datareader_read(string query, List<SqlParameter> parameters)
        {
            con.Open();
            cmd = new SqlCommand(query, con);
            if (parameters != null)
            {
                foreach (SqlParameter item in parameters)
                {
                    cmd.Parameters.Add(item);
                }
            }
            return cmd.ExecuteReader();
 
        }
    }
}
