﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Case_study_Data_Access_Layer;
using System.Collections;
using System.Data;

namespace Case_study_Business_layer
{
    public class BAL_Class
    {
        DAL_Class dal_obj = new DAL_Class();        // Common object for data access layer class
// Function for search box auto complete 
        public string[] getteam(string team)
        {
           return dal_obj.getteam(team);
        }
// Function which populates the group dropdown list
        public List<string> group_populate()
        {
            List<string> group_list = new List<string>();
            foreach (DataRow item in dal_obj.grouppopulate().Tables[0].Rows)
            {
                group_list.Add(item.ItemArray.GetValue(0).ToString());
            }       
            return group_list;
        }

// Function which populates the team dropdown list
        public List<string> team_populate(string group)
        {
           return dal_obj.teampopulate(group);
        }

// Function which populates the gridview with selected team details 
        public DataSet detailspopulate(string team)
        {           
            return dal_obj.detailspopulate(team);
        }

// Function which populates the gridview with selected table details of admin's choice 
        public DataSet db_table_populate(string table)
        {
           
            return dal_obj.db_table_populate(table);
        }

// Function which populates the tables dropdown list in admin page
        public List<string> ddl_table_populate()
        {
            List<string> table_list = new List<string>();
            foreach (DataRow item in dal_obj.table_dropdown_populate().Tables[0].Rows)
            {
                table_list.Add(item.ItemArray.GetValue(0).ToString());
            }
            return table_list;
        }
    }
}
