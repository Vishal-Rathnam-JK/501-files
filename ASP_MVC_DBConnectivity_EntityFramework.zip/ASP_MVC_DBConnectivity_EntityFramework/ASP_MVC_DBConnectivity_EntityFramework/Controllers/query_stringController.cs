﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ASP_MVC_DBConnectivity_EntityFramework.Controllers
{
    public class query_stringController : Controller
    {
        //
        // GET: /query_string/

        public ActionResult Index(string id,string name,string dept)
        {
            string res="emp name = "+name+", Department = "+dept;
            return Content(res);
        }

    }
}
