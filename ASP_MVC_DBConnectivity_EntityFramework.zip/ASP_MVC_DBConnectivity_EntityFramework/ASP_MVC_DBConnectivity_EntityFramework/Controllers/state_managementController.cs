﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASP_MVC_DBConnectivity_EntityFramework.Models;

namespace ASP_MVC_DBConnectivity_EntityFramework.Controllers
{
    public class state_managementController : Controller
    {
        //
        // GET: /state_management/
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection fc,student stud)
        {
            Session["info"] = fc["student_nationality"];
            


            return RedirectToAction("show", stud);
        }
        public ActionResult show(student stud)
        {
            return View(stud);
        }
    }
}
