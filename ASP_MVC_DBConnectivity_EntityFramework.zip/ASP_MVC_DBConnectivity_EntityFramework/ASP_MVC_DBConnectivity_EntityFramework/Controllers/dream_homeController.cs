﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace ASP_MVC_DBConnectivity_EntityFramework.Controllers
{
    public class dream_homeController : Controller
    {
        //
        // GET: /dream_home/

        public ActionResult get_all_branch()
        {
            dream_homeEntities dhe = new dream_homeEntities();
            List<branch> branch = (from d in dhe.branches select d).ToList<branch>();
            return View(branch);
        }
        public ActionResult accept_branch()
        {
            return View();
        }
        public ActionResult save_branch(branch bmod)
        {
            dream_homeEntities dhe = new dream_homeEntities();
            dhe.branches.Add(bmod);
            dhe.SaveChanges();
            return RedirectToAction("get_all_branch");
        }

        public ActionResult get_branch(string br_no)
        {
            dream_homeEntities dhe = new dream_homeEntities();
            branch b = dhe.branches.Find(br_no);
            return View(b);
        }

        public ActionResult delete_branch(string branch_no)
        {
            dream_homeEntities dhe = new dream_homeEntities();
            branch b = dhe.branches.Find(branch_no);
            dhe.branches.Remove(b);
           int result= dhe.SaveChanges();
            if (result>0)
            {

                ViewBag.information = "record deleted successfully";
                return RedirectToAction("get_all_branch");
            }
            else
            {
                ViewBag.information = "deletion failed";
                return View();
            }

        }



        public ActionResult update_branch(string branch)
        {
            dream_homeEntities dhe = new dream_homeEntities();
            branch b = dhe.branches.Find(branch);          
            return View(b);
        }

        [HttpPost]
        public ActionResult update_branch(branch bmod)
        {
            dream_homeEntities dhe = new dream_homeEntities();
            branch b = dhe.branches.Find(bmod.branchno);
            b.branchno = bmod.branchno;
            b.city = bmod.city;
            b.street = bmod.street;
            b.postcode = bmod.postcode;
            dhe.SaveChanges();          
                return RedirectToAction("get_all_branch");
        }
    }
}
