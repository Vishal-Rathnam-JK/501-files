﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MVC_Unit_test.Controllers;
using System.Web.Mvc;

namespace MVC_Unit_test.Tests
{
    [TestClass]
   public class test_validation
    {
        [TestMethod]
        public void testmethod1()
        {
            studentController studcont = new studentController();
            var res = studcont.change_data(1) as ViewResult ;
            Assert.AreEqual("B.E", res.ViewName);
        }
    }
}
