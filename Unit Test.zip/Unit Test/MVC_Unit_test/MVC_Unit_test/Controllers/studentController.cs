﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Unit_test.Controllers
{
    public class studentController : Controller
    {
        //
        // GET: /student/

        public ActionResult change_data(int type)
        {            
            if (type==1)
            {
               return View("B.E"); 
            }
            else if(type==2)
            {
                return View("MCA"); 
            }
            else
            {
                return Content("Not a valid choice");
            }            
        }
    }
}
