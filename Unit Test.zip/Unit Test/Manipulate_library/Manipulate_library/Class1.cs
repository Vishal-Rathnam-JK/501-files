﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Manipulate_library
{
    public class manipulate
    {
        public int addition(int a, int b)
        {
            return (a + b);
        }
        public bool show_result()
        {
            return true;
        }
    }
}
