﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Manipulate_library;

namespace validate_library
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()            //aaa
        {
            manipulate m = new manipulate();   // arrange
            int res = m.addition(5, 2);       //  act
            Assert.AreEqual(7, res);             // assert - return type is boolean           
        }
        [TestMethod]
        public void testmethod2()
        {
            manipulate m = new manipulate();
            bool res = m.show_result();
            Assert.AreEqual(true, res);
        }

        [TestMethod]
        public void testmethod3()
        {
            //List<string> l1 = new List<string>(){"A"};
            //List<string> l2 = new List<string>() { "B" };
            //CollectionAssert.AreEqual(l1, l2);
            List<string> l3 = new List<string>() { "a", "b", "c", "d" };
            //CollectionAssert.AllItemsAreUnique(l3);
           // CollectionAssert.Contains(l3, "a");
            CollectionAssert.AllItemsAreNotNull(l3);
        }
    }
}
